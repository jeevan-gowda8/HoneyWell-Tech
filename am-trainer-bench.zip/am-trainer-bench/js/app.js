(()=>{
'use strict';
const TAU=Math.PI*2, D2R=Math.PI/180;
const $=s=>document.querySelector(s);
const RF_OPTS=[100e3,200e3,455e3,1e6], RF_LBL=['100k','200k','455k','1M'];
const TBS=[1e-6,2e-6,5e-6,10e-6,20e-6,50e-6,100e-6,200e-6,500e-6,1e-3,2e-3,5e-3,10e-3];
const VDS=[0.005,0.01,0.02,0.05,0.1,0.2,0.5,1,2,5];
const CORDS=['#d8322b','#1c1f22','#e7b51c','#2f6fd6','#2e9e57','#e2771d','#8c4fd0'];
const FAULTS=['RF generator: no output','AF generator: no output','Audio pre-amp: no output','BM1: carrier null drifted','BM3: carrier input open','1 MHz BPF: detuned','Demodulator: carrier input open','Audio power amp: dead'];
const store={get(k,d){try{const v=localStorage.getItem(k); return v?JSON.parse(v):d;}catch(e){return d;}},set(k,v){try{localStorage.setItem(k,JSON.stringify(v));}catch(e){}}};

/* ---------------- signal engine: a signal is a list of tones {f, a, p} = a·cos(2πft+p) ---------------- */
function merge(s){
  const m=new Map();
  for(const c of s){ if(!(c.a>1e-9)) continue; const f=c.f<0.05?0:c.f; const k=Math.round(f*10);
    let e=m.get(k); if(!e){e={f,re:0,im:0}; m.set(k,e);} e.re+=c.a*Math.cos(c.p); e.im+=c.a*Math.sin(c.p); }
  const out=[];
  for(const e of m.values()){
    if(e.f===0){ const a=Math.abs(e.re); if(a>1e-7) out.push({f:0,a,p:e.re<0?Math.PI:0}); continue; }
    const a=Math.hypot(e.re,e.im); if(a>1e-7) out.push({f:e.f,a,p:Math.atan2(e.im,e.re)});
  }
  return out;
}
const gain=(s,k)=>s.map(c=>({f:c.f,a:c.a*Math.abs(k),p:c.p+(k<0?Math.PI:0)}));
function mul(s1,s2,k){
  const out=[];
  for(const x of s1) for(const y of s2){
    const a=k*x.a*y.a/2;
    out.push({f:x.f+y.f,a,p:x.p+y.p});
    let fd=x.f-y.f, pd=x.p-y.p; if(fd<0){fd=-fd;pd=-pd;}
    out.push({f:fd,a,p:pd});
  }
  return merge(out);
}
const filt=(s,H)=>s.map(c=>{const [m,ph]=H(c.f); return {f:c.f,a:c.a*m,p:c.p+ph};}).filter(c=>c.a>1e-7);
const chain=(...Hs)=>f=>{let m=1,p=0; for(const H of Hs){const r=H(f); m*=r[0]; p+=r[1];} return [m,p];};
const lp2=fc=>f=>{const x=f/fc, re=1-x*x, im=Math.SQRT2*x; return [1/Math.hypot(re,im), -Math.atan2(im,re)];};
const hp1=fc=>f=>{ if(f===0) return [0,0]; const x=f/fc; return [x/Math.hypot(1,x), Math.PI/2-Math.atan(x)];};
const res=(f0,Q)=>f=>{ if(f===0) return [0,0]; const y=Q*(f/f0-f0/f); return [1/Math.hypot(1,y), -Math.atan(y)];};
// 455 kHz SSB filter: flat passband ≈455.25–458.75 kHz (passes USB of a 455 kHz carrier), 60 dB floor
const ssbFilter=f=>{const x=(f-457000)/1750; return [Math.max(1/Math.sqrt(1+Math.pow(x,24)),0.001), -x*3];};

const VOICE=(()=>{ // sustained vowel "aa": 140 Hz fundamental shaped by three formants
  let seed=11; const rnd=()=>{seed=(seed*16807)%2147483647; return seed/2147483647;};
  const F=[[730,1,120],[1090,.55,140],[2440,.3,200]], out=[];
  for(let n=1;n*140<3600;n++){ const f=n*140; let g=0.18/n; for(const [fc,a,bw] of F) g+=a*Math.exp(-0.5*((f-fc)/bw)**2); out.push({f,a:g,p:rnd()*TAU}); }
  const sum=out.reduce((s,c)=>s+c.a,0); return out.map(c=>({...c,a:c.a*0.012/sum}));
})();

/* ---------------- board definition ---------------- */
const SOCK={}; const POS={};
// Layout follows the real trainer PCB, read with the title along the top:
// left column = generators, middle = balanced modulators 1–3, right = power, demodulator, SSB, RF stages, filters, audio amp.
// Socket entry: [id, label, io, x, y, designator, tpX, tpY, labelPos('a' above | 'b' below | 'l' left)]
const BLK=[
 {id:'afg',t:'AF SIGNAL GENERATOR',s:'AF GEN',x:20,y:72,w:360,h:258,
  sk:[['afg.out','AF OUT','o',318,118,'S2',318,186,'a']],kn:[['afFreq','FREQUENCY',195,104,1],['afAmp','AMPLITUDE',195,188,1]]},
 {id:'rfg',t:'RF SIGNAL GENERATOR',s:'RF GEN',x:20,y:330,w:360,h:256,
  sk:[['rfg.out','RF OUT','o',318,110,'S1',318,180,'a']],kn:[['rfAmp','AMPLITUDE',140,192,1]]},
 {id:'pre',t:'AUDIO PRE AMPLIFIER',s:'PRE-AMP',x:20,y:586,w:360,h:256,
  sk:[['pre.out','PRE-AMP OUT','o',318,110,'S10',318,180,'a']],kn:[]},
 ...[1,2,3].map(n=>({id:'bm'+n,t:'BALANCED MODULATOR '+n,s:'BM'+n,x:380,y:[72,330,586][n-1],w:420,h:n===1?258:256,
   sk:[['bm'+n+'.mod','MODULATING SIGNAL','i',66,112,'S'+(n*3+1),66,178,'a'],['bm'+n+'.car','RF CARRIER SIGNAL','i',150,206,'S'+(n*3),104,206,'b'],['bm'+n+'.out','DSB SC SIGNAL','o',372,130,'S'+(n*3+2),372,196,'a']],
   kn:[['bm'+n,'CARRIER NULL',168,62,1]],bm:n})),
 {id:'pwr',t:'POWER',s:'PWR',x:800,y:18,w:380,h:94,sk:[],kn:[]},
 {id:'dem',t:'BALANCED DEMODULATOR',s:'DEMOD',x:800,y:112,w:380,h:178,
  sk:[['dem.sig','SIGNAL IN','i',44,78,'S13',44,140,'a'],['dem.car','CARRIER','i',152,150,'S14',192,150,'l'],['dem.out','DEMOD OUT','o',342,78,'S15',342,140,'a']],kn:[]},
 {id:'ssb',t:'SSB BLOCK',s:'SSB',x:800,y:290,w:380,h:170,
  sk:[['ssb.afin','AF IN','i',34,64,'',0,0,'b'],['ssb.afout','AF 90°','o',104,64,'',0,0,'b'],['ssb.rfin','RF IN','i',34,132,'',0,0,'b'],['ssb.rfout','RF 90°','o',104,132,'',0,0,'b'],
      ['ssb.a','SUM A','i',222,64,'',0,0,'b'],['ssb.b','SUM B','i',222,132,'',0,0,'b'],['ssb.out','SSB OUT','o',340,98,'S16',0,0,'a']],
  kn:[['ssbAf','φ AF',160,64,0],['ssbRf','φ RF',160,132,0]]},
 {id:'rpa',t:'1MHz POWER AMPLIFIER',s:'RF PA',x:800,y:460,w:190,h:176,sk:[['rpa.in','IN','i',28,150,'S19',0,0,'a'],['rpa.out','OUT','o',162,150,'S20',0,0,'a']],kn:[]},
 {id:'rpre',t:'1MHz PRE AMPLIFIER',s:'RF PRE',x:990,y:460,w:190,h:176,sk:[['rpre.in','IN','i',28,150,'S17',0,0,'a'],['rpre.out','OUT','o',162,150,'S18',0,0,'a']],kn:[]},
 {id:'b455',t:'455KHz BPF',s:'455k BPF',x:800,y:636,w:190,h:108,sk:[['b455.in','IN','i',28,72,'S21',0,0,'a'],['b455.out','OUT','o',162,72,'S22',0,0,'a']],kn:[]},
 {id:'b1m',t:'1MHz BPF',s:'1M BPF',x:990,y:636,w:190,h:108,sk:[['b1m.in','IN','i',28,72,'S23',0,0,'a'],['b1m.out','OUT','o',162,72,'S24',0,0,'a']],kn:[]},
 {id:'apa',t:'AUDIO POWER AMPLIFIER',s:'AUDIO PA',x:800,y:744,w:380,h:98,sk:[['apa.in','IN','i',32,58,'S25',0,0,'b'],['apa.out','SPK','o',272,58,'TP28',0,0,'b']],kn:[['vol','VOLUME',150,56,0]]},
];
for(const b of BLK) for(const [id,l,io,dx,dy,des,tx,ty,lp] of b.sk){ SOCK[id]={id,l,io,blk:b,des,lp,tp:tx?[b.x+tx,b.y+ty]:null}; POS[id]=[b.x+dx,b.y+dy]; }
const sockName=id=>SOCK[id].blk.s+' · '+SOCK[id].l;

const KN={
  afFreq:{l:'Frequency',min:100,max:10000,log:true,g:'afg'}, afAmp:{l:'Amplitude',min:0,max:4,g:'afg'},
  rfAmp:{l:'Amplitude',min:0,max:1,g:'rfg'}, preGain:{l:'Gain',min:10,max:100,log:true,g:'pre'},
  bm1:{l:'Carrier null',min:-1,max:1,g:'bm1'}, bm2:{l:'Carrier null',min:-1,max:1,g:'bm2'}, bm3:{l:'Carrier null',min:-1,max:1,g:'bm3'},
  demPh:{l:'Carrier phase (sim)',min:-180,max:180,g:'dem'}, demDf:{l:'Carrier frequency offset (sim)',min:-50,max:50,g:'dem'},
  ssbAf:{l:'AF phase trim',min:-30,max:30,g:'ssb'}, ssbRf:{l:'RF phase trim',min:-30,max:30,g:'ssb'},
  vol:{l:'Volume',min:0,max:1,g:'apa'},
};
const norm=(k,v)=>{const m=KN[k]; return m.log? Math.log(v/m.min)/Math.log(m.max/m.min) : (v-m.min)/(m.max-m.min);};
const denorm=(k,n)=>{const m=KN[k]; n=Math.min(1,Math.max(0,n)); let v=m.log? m.min*Math.pow(m.max/m.min,n) : m.min+n*(m.max-m.min);
  if(k==='afFreq') v=v<1000?Math.round(v/10)*10:Math.round(v/50)*50;
  else if(k==='preGain'||k==='demPh') v=Math.round(v);
  else if(k==='demDf') v=Math.round(v*2)/2;
  else if(k.startsWith('ssb')) v=Math.round(v*2)/2;
  else v=Math.round(v*100)/100; return v;};
function fmtK(k,v){
  if(k==='afFreq') return fHz(v); if(k==='afAmp') return v.toFixed(2)+' Vpp'; if(k==='rfAmp') return Math.round(v*1000)+' mVpp';
  if(k==='preGain') return '×'+v.toFixed(0); if(k.startsWith('bm')) return (v>0?'+':'')+v.toFixed(2);
  if(k==='demDf') return (v>0?'+':'')+v.toFixed(1)+' Hz';
  if(k==='vol') return (v*10).toFixed(1); return (v>0?'+':'')+v.toFixed(k==='demPh'?0:1)+'°';
}
function fHz(f){ if(!f) return '—'; if(f>=1e6) return (f/1e6).toFixed(4)+' MHz'; if(f>=1e4) return (f/1e3).toFixed(3)+' kHz'; if(f>=1e3) return (f/1e3).toFixed(2)+' kHz'; return f.toFixed(0)+' Hz'; }
function fV(v){ if(v==null||!isFinite(v)) return '—'; if(v<1e-3) return (v*1e3).toFixed(2)+' mV'; if(v<1) return (v*1e3).toFixed(0)+' mV'; return v.toFixed(2)+' V'; }
function fT(t){ const a=Math.abs(t); if(a<1e-3) return (t*1e6).toFixed(1)+' µs'; return (t*1e3).toFixed(3)+' ms'; }
function fP(p){ if(!isFinite(p)) return '—'; if(p<1e-3) return (p*1e6).toFixed(1)+' µW'; return (p*1e3).toFixed(2)+' mW'; }
const fTB=t=>t<1e-3? Math.round(t*1e6)+' µs' : Math.round(t*1e3)+' ms';
const fVd=v=>v<1? Math.round(v*1e3)+' mV' : v+' V';
const fdB=x=>(x==null||!isFinite(x))?'—':x.toFixed(1)+' dB';

/* ---------------- state ---------------- */
const S={
  ctl:{afFreq:1000,afAmp:2,afWave:'sine',rfSel:0,rfAmp:0.5,mic:true,preGain:30,bm1:0,bm2:0,bm3:0,demPh:0,demDf:0,ssbAf:0,ssbRf:0,ssbMode:1,vol:0.5},
  faults:Array(8).fill(false), hidden:null, wires:[], cordN:0, probes:{1:'afg.out',2:'bm1.out'},
  mode:'patch', pending:null, exp:0, t0:0,
  scope:{tb:200e-6,v1:0.5,v2:0.1,pos1:2,pos2:-2,xy:false,ch2:true,run:true,trig:'sync',cur:false,c1:0.25,c2:0.65}, spec:{src:2,view:'auto',labels:true},
};
const F=i=>S.faults[i]||S.hidden===i;

/* ---------------- block models ---------------- */
const cache=new Map(), busy=new Set();
function sig(id){
  if(!id||!SOCK[id]) return [];
  if(cache.has(id)) return cache.get(id);
  if(busy.has(id)) return [];
  busy.add(id); let r;
  try{ r= SOCK[id].io==='i' ? inSig(id) : outSig(id); } finally{ busy.delete(id); }
  cache.set(id,r); return r;
}
function inSig(id){ const w=S.wires.find(w=>w.to===id); return w? sig(w.from) : []; }
function bm(n){
  const m=sig('bm'+n+'.mod'); let c=sig('bm'+n+'.car');
  if(n===3&&F(4)) c=[];
  let bal=S.ctl['bm'+n]; if(n===1&&F(3)) bal=0.75;
  const leak=(0.004+bal)*4; // carrier re-inserted by an unbalanced null trimmer
  return merge([...mul(m,c,2), ...gain(c,leak), ...gain(m,0.01)]);
}
function afSig(){
  const c=S.ctl, A=c.afAmp/2, f=c.afFreq;
  if(c.afWave==='sine') return [{f,a:A,p:0}];
  const out=[];
  for(let n=1,k=0;n<=15&&n*f<20000;n+=2,k++){
    if(c.afWave==='square') out.push({f:n*f,a:A*4/Math.PI/n,p:k%2?Math.PI:0});
    else out.push({f:n*f,a:A*8/(Math.PI*Math.PI)/(n*n),p:0});
  }
  return out;
}
function outSig(id){
  const c=S.ctl;
  switch(id){
    case 'afg.out': return F(1)?[]:afSig();
    case 'rfg.out': return F(0)?[]:[{f:RF_OPTS[c.rfSel],a:c.rfAmp/2,p:0}];
    case 'pre.out': return (!c.mic||F(2))?[]:filt(gain(VOICE,c.preGain),chain(hp1(120),lp2(4000)));
    case 'bm1.out': return bm(1); case 'bm2.out': return bm(2); case 'bm3.out': return bm(3);
    case 'dem.out': {
      const s=sig('dem.sig'); let lo=F(6)?[]:sig('dem.car'); const ph=c.demPh*D2R;
      lo=lo.map(x=>({f:x.f+(x.f>1000?c.demDf:0),a:x.a,p:x.p+ph}));
      return filt(mul(s,lo,8), chain(lp2(6000),lp2(6000),hp1(20)));
    }
    case 'ssb.afout': return filt(sig('ssb.afin'), ()=>[1,-Math.PI/2+c.ssbAf*D2R]);
    case 'ssb.rfout': return filt(sig('ssb.rfin'), ()=>[1,-Math.PI/2+c.ssbRf*D2R]);
    case 'ssb.out': return merge([...sig('ssb.a'), ...gain(sig('ssb.b'), c.ssbMode)]);
    case 'rpre.out': return filt(sig('rpre.in'), chain(res(1e6,6),()=>[3,0]));
    case 'rpa.out': return filt(sig('rpa.in'), chain(res(1e6,1.5),()=>[2,0]));
    case 'b455.out': return filt(sig('b455.in'), ssbFilter);
    case 'b1m.out': { const f0=F(5)?0.9e6:1e6; return filt(sig('b1m.in'), chain(res(f0,25),res(f0,25))); }
    case 'apa.out': return F(7)?[]:filt(sig('apa.in'), chain(lp2(8000),hp1(30),()=>[4*c.vol,0]));
  }
  return [];
}

/* ---------------- measurement ---------------- */
function analyze(s){
  const r={vpp:0,f:0,isRF:false,fl:0,kind:'none'};
  const sg=s.filter(c=>c.a>1e-5); if(!sg.length) return r;
  let dom=null; for(const c of sg) if(c.f>0&&(!dom||c.a>dom.a)) dom=c;
  if(!dom){ r.kind='dc'; return r; }
  r.f=dom.f; r.isRF=dom.f>20000;
  if(r.isRF){
    const rf=RF_OPTS[S.ctl.rfSel];
    const fc=sg.some(c=>Math.abs(c.f-rf)<30000)? rf : dom.f; r.fc=fc;
    const near=sg.filter(c=>Math.abs(c.f-fc)<30000);
    let car=0,lsb=0,usb=0,lA=0,uA=0,lsbF=0,usbF=0,minSp=Infinity,pc=0,psb=0;
    for(const c of near){ const d=c.f-fc, p=c.a*c.a/2/50;
      if(Math.abs(d)<2){ car+=c.a; pc+=p; }
      else { psb+=p; if(Math.abs(d)<minSp) minSp=Math.abs(d);
        if(d<0){lsb+=c.a; if(c.a>lA){lA=c.a;lsbF=c.f;}} else {usb+=c.a; if(c.a>uA){uA=c.a;usbF=c.f;}} } }
    const W=isFinite(minSp)? 2/minSp : 1e-3; let emax=0,emin=Infinity;
    for(let i=0;i<1600;i++){ const t=i/1600*W; let re=0,im=0;
      for(const c of near){ const ph=TAU*(c.f-fc)*t+c.p; re+=c.a*Math.cos(ph); im+=c.a*Math.sin(ph); }
      const e=Math.hypot(re,im); if(e>emax) emax=e; if(e<emin) emin=e; }
    Object.assign(r,{car,lsb,usb,lsbF,usbF,emax:2*emax,emin:2*emin,vpp:2*emax,pc,psb});
    r.fl= isFinite(minSp)? minSp : fc;
    const sb=lsb+usb;
    r.mu= car>1e-4 ? sb/car : null;
    if(sb<1e-4) r.kind='carrier';
    else if(lsb>usb*10) r.kind='lsb'; else if(usb>lsb*10) r.kind='usb';
    else if(car<0.05*sb) r.kind='dsb'; else r.kind= r.mu>1.001?'over':'am';
  } else {
    const amax=Math.max(...sg.map(c=>c.a));
    const fmin=Math.min(...sg.filter(c=>c.f>0&&c.a>0.1*amax).map(c=>c.f));
    r.fl=fmin; const W=2/fmin; let mx=-Infinity,mn=Infinity;
    const N=4000; for(let i=0;i<N;i++){ const t=i/N*W; let v=0; for(const c of sg) v+=c.a*Math.cos(TAU*c.f*t+c.p); if(v>mx)mx=v; if(v<mn)mn=v; }
    r.vpp=mx-mn; r.kind='base';
    const h1=sg.find(c=>Math.abs(c.f-fmin)<0.5); if(h1){ const hs=sg.filter(c=>c.f>fmin*1.5&&Math.abs(c.f/fmin-Math.round(c.f/fmin))<0.01); r.thd=Math.sqrt(hs.reduce((s,c)=>s+c.a*c.a,0))/h1.a*100; }
  }
  return r;
}
const vppAt=id=>analyze(sig(id)).vpp;
const KIND={none:['No signal','bad'],dc:['DC only','warn'],base:['Baseband',''],carrier:['Carrier only','warn'],dsb:['DSB-SC','ok'],am:['AM','ok'],over:['Over-modulated','bad'],usb:['SSB · USB','ok'],lsb:['SSB · LSB','ok']};

/* ---------------- experiments ---------------- */
const W_DSB=[['afg.out','bm1.mod'],['rfg.out','bm1.car']];
const W_VOICE=[['pre.out','bm3.mod'],['rfg.out','bm3.car'],['bm3.out','rpre.in'],['rpre.out','b1m.in'],['b1m.out','rpa.in'],['rpa.out','dem.sig'],['rfg.out','dem.car'],['dem.out','apa.in']];
const EXP=[
 {id:'dsb',short:'DSB-SC generation',title:'Generation of DSB-SC using a balanced modulator',
  aim:'Generate a double-sideband suppressed-carrier signal with Balanced Modulator 1 and study its waveform and spectrum.',
  th:['A balanced modulator multiplies the message by the carrier. The carrier appears in both halves of the circuit with opposite polarity and cancels.',
      's(t) = k·m(t)·c(t)\n     = (k·Am·Ac / 2)·[cos 2π(fc − fm)t + cos 2π(fc + fm)t]',
      'Only the two sidebands at fc ± fm remain. The RF phase flips by 180° each time m(t) crosses zero.'],
  wires:W_DSB, pre:{ctl:{rfSel:0,rfAmp:0.5,afFreq:1000,afAmp:2,afWave:'sine',bm1:0},scope:{tb:200e-6,v1:0.5,v2:0.1,pos1:2,pos2:-2,xy:false,ch2:true},probes:{1:'afg.out',2:'bm1.out'},spec:{src:2,view:'auto'}},
  steps:['Select <b>100k</b> on the RF generator DIP switch and set RF amplitude to 500 mVpp.','Set the AF generator to 1 kHz, 2 Vpp, sine.','Patch AF OUT to BM1 MODULATING SIGNAL, and RF OUT to BM1 RF CARRIER SIGNAL.','Probe CH1 on AF OUT and CH2 on BM1 DSB-SC OUT, then press Autoset.','Trim BM1 CARRIER NULL until the 100 kHz line on the spectrum analyzer is at its lowest.','Record a reading, then repeat for fm = 2 kHz and 3 kHz. Try a square-wave message and count the sideband pairs.'],
  expect:'The DSB-SC envelope follows |m(t)| and pinches to zero twice per AF cycle. The spectrum shows two equal lines at fc − fm and fc + fm, with the carrier at least 30 dB below them.',
  cols:['fm','Vm (pp)','fc','DSB-SC (pp)','LSB','USB','Carrier supp.'], plot:[0,3],
  row(){const a=analyze(sig('bm1.out')); const sb=(a.lsb+a.usb)/2; return [fHz(S.ctl.afFreq),fV(vppAt('afg.out')),fHz(RF_OPTS[S.ctl.rfSel]),fV(a.vpp),fHz(a.lsbF),fHz(a.usbF),a.car>1e-7?fdB(20*Math.log10(sb/a.car)):'> 60 dB'];},
  viva:[['Why is the carrier absent at the output of a balanced modulator?','The modulator is a multiplier with a differential structure. The carrier term appears in both halves with opposite polarity and cancels, so only product terms remain.'],['What bandwidth does DSB-SC need?','2·fm, the same as AM, because both sidebands are sent.'],['Why can’t an envelope detector recover DSB-SC?','The envelope is |m(t)|, not m(t). The sign is carried by the phase reversals, so a coherent (synchronous) detector is needed.']]},
 {id:'am',short:'AM and modulation index',title:'AM (DSB-FC) generation and modulation index',
  aim:'Re-insert the carrier by unbalancing the modulator, producing conventional AM, and measure the modulation index μ.',
  th:['Turning CARRIER NULL off-centre lets part of the carrier through the modulator:',
      's(t) = Ac′·[1 + μ·cos 2πfm t]·cos 2πfc t\n\nμ = (Emax − Emin) / (Emax + Emin)\n  = (USB + LSB) / carrier      (amplitudes)\n\nPt = Pc·(1 + μ²/2)      η = μ² / (2 + μ²)',
      'The envelope formula only holds for μ ≤ 1. Beyond that the envelope folds over and the spectrum value is the reliable one.'],
  wires:W_DSB, pre:{ctl:{rfSel:0,rfAmp:0.5,afFreq:1000,afAmp:1,afWave:'sine',bm1:0.5},scope:{tb:200e-6,v1:0.5,v2:0.5,pos1:2,pos2:-1.5,xy:false,ch2:true},probes:{1:'afg.out',2:'bm1.out'},spec:{src:2,view:'auto'}},
  steps:['Patch AF OUT → BM1 MODULATING SIGNAL and RF OUT → BM1 RF CARRIER SIGNAL. RF at 100 kHz, AF at 1 kHz.','Turn BM1 CARRIER NULL away from centre. A carrier line appears at 100 kHz and the envelope no longer reaches zero.','With AF amplitude at 1 Vpp, read Emax and Emin from the Modulation card and calculate μ.','Raise the AF amplitude until Emin just reaches zero (μ = 1), then go further to see over-modulation.','Tick XY mode with CH1 on AF OUT and CH2 on BM1 OUT to see the trapezoid pattern.','Record readings for at least four AF amplitudes and check the μ-vs-Vm plot is a straight line.'],
  expect:'Under-modulation: the envelope stays above zero and the trapezoid has a short left edge. At μ = 1 the trapezoid becomes a triangle and efficiency reaches 33.3 %. Over-modulation: the envelope folds and the card flags it.',
  cols:['Vm (pp)','Emax (pp)','Emin (pp)','μ envelope','μ spectrum','η'], plot:[0,4],
  row(){const a=analyze(sig('bm1.out')); const me=(a.emax-a.emin)/(a.emax+a.emin); const eta=a.psb/(a.pc+a.psb)*100; return [fV(vppAt('afg.out')),fV(a.emax),fV(a.emin),isFinite(me)?me.toFixed(3):'—',a.mu!=null?a.mu.toFixed(3):'—',isFinite(eta)?eta.toFixed(1)+' %':'—'];},
  viva:[['What happens to total power as μ goes from 0 to 1?','It rises from Pc to 1.5·Pc. The sidebands carry at most one third of the total power.'],['Why should over-modulation be avoided?','The envelope no longer follows m(t), which causes distortion at the detector and spreads energy outside the channel (splatter).'],['What does the trapezoid pattern show?','Its two vertical edges are Emax and Emin. Straight sloping sides show the modulator is linear.']]},
 {id:'ssbf',short:'SSB by filter method',title:'SSB generation by the filter method',
  aim:'Make DSB-SC at 455 kHz with Balanced Modulator 2 and keep one sideband with the 455 kHz band-pass filter.',
  th:['The 455 kHz BPF has a passband of about 455.25–458.75 kHz, so with a 455 kHz carrier only the upper sideband passes:',
      's_USB(t) = (k·Am·Ac / 2)·cos 2π(fc + fm)t',
      'The filter has to go from passband to stopband within 2·fm(min). That is why voice SSB starts at about 300 Hz.'],
  wires:[['afg.out','bm2.mod'],['rfg.out','bm2.car'],['bm2.out','b455.in']],
  pre:{ctl:{rfSel:2,rfAmp:0.5,afFreq:1000,afAmp:2,afWave:'sine',bm2:0},scope:{tb:200e-6,v1:0.1,v2:0.1,pos1:2,pos2:-2,xy:false,ch2:true},probes:{1:'bm2.out',2:'b455.out'},spec:{src:2,view:'car5'}},
  steps:['Select <b>455k</b> on the RF generator.','Patch AF OUT → BM2 MODULATING SIGNAL, RF OUT → BM2 RF CARRIER SIGNAL, and BM2 DSB-SC OUT → 455 kHz BPF IN.','Null the carrier with BM2 CARRIER NULL.','Probe CH1 on BM2 DSB-SC OUT and CH2 on 455 kHz BPF OUT.','Switch the spectrum input between CH1 and CH2. Only the line at 455 kHz + fm passes the filter.','Sweep fm from 300 Hz to 5 kHz and record. The plot traces the filter response.'],
  expect:'The SSB output is a single RF tone with a flat envelope. Rejection is above 40 dB at 1 kHz, drops near 300 Hz, and the wanted sideband itself fades above about 3.5 kHz.',
  cols:['fm','DSB-SC (pp)','SSB (pp)','SSB freq','LSB rejection'], plot:[0,2],
  row(){const d=analyze(sig('bm2.out')), s=analyze(sig('b455.out')); return [fHz(S.ctl.afFreq),fV(d.vpp),fV(s.vpp),fHz(s.usbF||s.f),(s.lsb>0&&s.usb>0)?fdB(20*Math.log10(s.usb/s.lsb)):'—'];},
  viva:[['Why is SSB generated at a low IF like 455 kHz and not directly at the final RF?','A sharp filter with a few kHz bandwidth is practical at 455 kHz. At high RF the required Q would be impractical.'],['What limits the lowest audio frequency in the filter method?','The sidebands are 2·fm apart. The filter skirt must fall from pass to stop within that gap.'],['What bandwidth does SSB occupy?','fm(max), half of AM or DSB-SC.']]},
 {id:'ssbp',short:'SSB by phase-shift method',title:'SSB generation by the phase-shift method',
  aim:'Drive two balanced modulators in quadrature and add or subtract their outputs to cancel one sideband.',
  th:['BM1 gets the plain signals, BM2 gets both shifted by 90°:',
      'BM1:  cos ωm t · cos ωc t = ½[cos(ωc−ωm)t + cos(ωc+ωm)t]\nBM2:  sin ωm t · sin ωc t = ½[cos(ωc−ωm)t − cos(ωc+ωm)t]\n\nA + B → lower sideband\nA − B → upper sideband',
      'A phase error θ in either shifter leaves part of the unwanted sideband, about tan(θ/2) of the wanted one.'],
  wires:[['afg.out','bm1.mod'],['afg.out','ssb.afin'],['ssb.afout','bm2.mod'],['rfg.out','bm1.car'],['rfg.out','ssb.rfin'],['ssb.rfout','bm2.car'],['bm1.out','ssb.a'],['bm2.out','ssb.b']],
  pre:{ctl:{rfSel:0,rfAmp:0.5,afFreq:1000,afAmp:2,afWave:'sine',bm1:0,bm2:0,ssbAf:0,ssbRf:0,ssbMode:1},scope:{tb:200e-6,v1:0.2,v2:0.2,pos1:2,pos2:-2,xy:false,ch2:true},probes:{1:'bm1.out',2:'ssb.out'},spec:{src:2,view:'car5'}},
  steps:['Select 100k on the RF generator. AF at 1 kHz, 2 Vpp.','Patch AF OUT to both BM1 MODULATING SIGNAL and SSB AF IN. Patch SSB AF 90° to BM2 MODULATING SIGNAL.','Patch RF OUT to both BM1 RF CARRIER and SSB RF IN. Patch SSB RF 90° to BM2 RF CARRIER.','Patch BM1 OUT to SUM A and BM2 OUT to SUM B.','Null both modulators, probe SSB OUT and note which sideband remains.','Flip the summer switch between A+B and A−B. Then add phase error with the φ AF trim in 2° steps and record the suppression.'],
  expect:'With A+B only the line at fc − fm remains; with A−B only fc + fm. A 5° error lowers suppression to roughly 27 dB.',
  cols:['Summer','fm','φ error','SSB (pp)','Output freq','Suppression'], plot:[2,5],
  row(){const s=analyze(sig('ssb.out')); const w=Math.max(s.lsb,s.usb), u=Math.min(s.lsb,s.usb); return [S.ctl.ssbMode>0?'A+B':'A−B',fHz(S.ctl.afFreq),(S.ctl.ssbAf+S.ctl.ssbRf).toFixed(1)+'°',fV(s.vpp),fHz(s.lsb>s.usb?s.lsbF:s.usbF),u>1e-7?fdB(20*Math.log10(w/u)):'> 60 dB'];},
  viva:[['Why is the phase-shift method hard to build for voice?','The AF shifter must give exactly 90° over the whole 300–3400 Hz band, which needs a wideband (Hilbert) network.'],['How do you switch between USB and LSB?','Change the summer from addition to subtraction, or swap the sign of one quadrature path.'],['What happens if the two modulator gains differ?','The unwanted sideband no longer cancels fully, just as with a phase error.']]},
 {id:'demod',short:'Synchronous demodulation',title:'Demodulation with the balanced demodulator',
  aim:'Recover the message from DSB-SC by coherent (synchronous) detection and see how carrier phase and frequency errors affect it.',
  th:['The demodulator multiplies the received signal by a local carrier and low-pass filters the product:',
      'DSB-SC · cos(ωc t + φ)  →  LPF  →  (k′/2)·m(t)·cos φ\n\nwith offset Δf:  (k′/2)·m(t)·cos(2πΔf t + φ)',
      'At φ = 90° the output disappears (quadrature null). A small frequency offset makes the recovered tone swell and fade (beating). Phase and offset are simulation aids; the real kit takes its carrier straight from the RF generator.'],
  wires:[['afg.out','bm1.mod'],['rfg.out','bm1.car'],['bm1.out','dem.sig'],['rfg.out','dem.car'],['dem.out','apa.in']],
  pre:{ctl:{rfSel:0,rfAmp:0.5,afFreq:1000,afAmp:2,afWave:'sine',bm1:0,demPh:0,demDf:0,vol:0.5},scope:{tb:200e-6,v1:0.5,v2:0.2,pos1:2,pos2:-2,xy:false,ch2:true},probes:{1:'afg.out',2:'dem.out'},spec:{src:2,view:'base'}},
  steps:['Patch AF OUT → BM1 MODULATING, RF OUT → BM1 RF CARRIER, BM1 OUT → DEMOD SIGNAL IN, RF OUT → DEMOD CARRIER IN, DEMOD OUT → AUDIO PA IN.','Probe CH1 on AF OUT and CH2 on DEMOD OUT. The recovered tone has the same frequency as fm.','Press Speaker on (or click the speaker on the board) to hear the recovered tone.','Step the demodulator PHASE from 0° to 180° in 30° steps and record the output. The plot follows cos φ.','Return phase to 0° and set OFFSET to +5 Hz. At 50 ms/div you can see the output beating.','Optional: feed 455 kHz BPF OUT into DEMOD SIGNAL IN with the RF at 455 kHz and repeat. The SSB output amplitude stays constant with phase.'],
  expect:'Output amplitude follows cos φ: maximum at 0°, zero at 90°, inverted at 180°. The 2fc product is removed by the low-pass filter.',
  cols:['φ','Vm (pp)','Demod out (pp)','Out / in','cos φ'], plot:[0,2],
  row(){const vi=vppAt('afg.out'), vo=vppAt('dem.out'); return [S.ctl.demPh+'°',fV(vi),fV(vo),vi>0?(vo/vi).toFixed(3):'—',Math.cos(S.ctl.demPh*D2R).toFixed(3)];},
  viva:[['Why must the local carrier be synchronous?','A frequency error Δf turns the output into m(t)·cos(2πΔf t), a beating distortion. A phase error scales DSB output by cos φ.'],['What does the low-pass filter remove?','The component at 2fc produced by the multiplication.'],['Is synchronous detection needed for normal AM?','No. With enough carrier, an envelope detector works, which is why broadcast AM uses it.']]},
 {id:'voice',short:'Voice link at 1 MHz',title:'Complete voice link through the 1 MHz chain',
  aim:'Send a microphone signal through every stage of the kit and recover it at the speaker.',
  th:['The microphone signal is amplified, modulated onto a 1 MHz carrier in BM3, raised by the tuned pre-amplifier, cleaned by the 1 MHz BPF, driven by the power amplifier and recovered by the balanced demodulator and audio amplifier.',
      'MIC → PRE-AMP → BM3 (×1 MHz) → RF PRE AMP → 1 MHz BPF\n    → RF POWER AMP → DEMOD (×1 MHz) → AUDIO PA → SPEAKER',
      'The simulated microphone holds a steady vowel “aa” (140 Hz fundamental with formants near 730, 1090 and 2440 Hz).'],
  wires:W_VOICE,
  pre:{ctl:{rfSel:3,rfAmp:0.5,mic:true,preGain:30,bm3:0,demPh:0,demDf:0,vol:0.5},scope:{tb:2e-3,v1:0.2,v2:0.5,pos1:2,pos2:-2,xy:false,ch2:true},probes:{1:'pre.out',2:'dem.out'},spec:{src:1,view:'base'}},
  steps:['Select <b>1M</b> on the RF generator and switch the microphone on.','Patch the chain in order: PRE-AMP OUT → BM3 MODULATING, RF OUT → BM3 CARRIER, BM3 OUT → RF PRE IN, RF PRE OUT → 1 MHz BPF IN, BPF OUT → RF PA IN, RF PA OUT → DEMOD SIGNAL, RF OUT → DEMOD CARRIER, DEMOD OUT → AUDIO PA IN.','Probe each stage in turn. Watch the voice spectrum on CH1 and the RF spectrum when probing BM3 or RF PA.','Turn the speaker on and compare the recovered vowel with the pre-amp output.','Switch the RF generator to 455k. The 1 MHz tuned stages reject it and the link fades.'],
  expect:'The voice spectrum (lines every 140 Hz) appears as sidebands around 1 MHz after BM3, passes the tuned stages, and returns unchanged at DEMOD OUT.',
  cols:['RF','Pre-amp (pp)','BM3 (pp)','RF PA (pp)','Demod (pp)'], plot:null,
  row(){return [fHz(RF_OPTS[S.ctl.rfSel]),fV(vppAt('pre.out')),fV(vppAt('bm3.out')),fV(vppAt('rpa.out')),fV(vppAt('dem.out'))];},
  viva:[['Why are the RF amplifiers tuned rather than broadband?','Tuning gives gain at 1 MHz and rejects harmonics, the audio feedthrough and out-of-band signals.'],['Why is the BPF placed between the two RF amplifiers?','It removes the products and noise of the first stage before the power amplifier boosts them.'],['What does the audio pre-amplifier do?','It lifts the millivolt microphone signal to the level the balanced modulator needs.']]},
 {id:'fault',short:'Fault finding',title:'Fault finding on the voice link',
  aim:'Locate a hidden fault in the 1 MHz voice link by probing stage by stage.',
  th:['Signal tracing: start at the source and probe each socket along the path. The fault lies between the last good point and the first bad one.',
      'Good point  →  [faulty stage]  →  bad point',
      'The board’s FAULT DIP bank is covered while a hidden fault is active.'],
  wires:W_VOICE,
  pre:{ctl:{rfSel:3,rfAmp:0.5,mic:true,preGain:30,bm3:0,demPh:0,demDf:0,vol:0.5},scope:{tb:2e-3,v1:0.2,v2:0.5,pos1:2,pos2:-2,xy:false,ch2:true},probes:{1:'pre.out',2:'dem.out'},spec:{src:2,view:'auto'}},
  steps:['Press Auto-wire, then Insert hidden fault.','Probe the chain from PRE-AMP OUT to SPK one socket at a time and compare with Experiment 6.','Mark where the signal disappears or changes.','Pick your diagnosis and press Check.'],
  expect:'Each fault kills or degrades the signal at one stage only. Probing both sides of a stage identifies it.',
  cols:['Attempt','Diagnosis','Result'], row:null, plot:null,
  viva:[['Why probe the input and output of a stage?','A good input with a bad output isolates the fault to that stage.'],['How would a detuned BPF show up?','The RF level falls at the BPF output while its input looks normal.']]},
];

/* ---------------- board drawing ---------------- */
const NS='http://www.w3.org/2000/svg';
function E(tag,attrs,parent){const e=document.createElementNS(NS,tag); if(attrs) for(const k in attrs) e.setAttribute(k,attrs[k]); if(parent) parent.appendChild(e); return e;}
function T(parent,x,y,txt,attrs){const t=E('text',Object.assign({x,y},attrs||{}),parent); t.textContent=txt; return t;}
const SILK='#f1f6ef', MONO='JetBrains Mono, Consolas, monospace', TRACE='#1a8150';
let gW,gS,gP,pendLine;
const knobEls={}, dyn={};
let seedR=5; const rnd=()=>{seedR=(seedR*16807)%2147483647; return seedR/2147483647;};
const BANDS=['#1b1b1b','#7a4a1e','#c62828','#ef7d1a','#e8c21a','#2e7d32','#1e5bc6','#7b3fb3','#8a8a8a'];

/* component library: top-view drawings of the parts used on the trainer */
function silk(g,x,y,txt,size,attrs){ return T(g,x,y,txt,Object.assign({'font-size':size||8,fill:SILK,opacity:.8},attrs||{})); }
function rz(g,x,y,v,lbl){ const r=E('g',{transform:`translate(${x},${y})${v?' rotate(90)':''}`},g);
  E('line',{x1:-14,y1:0,x2:14,y2:0,stroke:'#c3c7cb','stroke-width':1.3},r);
  E('rect',{x:-8.5,y:-3.4,width:17,height:6.8,rx:3.2,fill:'#dcc493',stroke:'#a88f5e','stroke-width':.6},r);
  for(let i=0;i<4;i++) E('rect',{x:-6+i*3.3+(i===3?1.8:0),y:-3.4,width:1.6,height:6.8,fill:i===3?'#c9a23a':BANDS[Math.floor(rnd()*BANDS.length)]},r);
  if(lbl) silk(g,v?x+6:x,v?y+3:y-6,lbl,7.5,{'text-anchor':v?'start':'middle'}); }
function cc(g,x,y,col,lbl){ E('ellipse',{cx:x,cy:y+.8,rx:6.4,ry:5.3,fill:'rgba(0,0,0,.25)'},g);
  E('ellipse',{cx:x,cy:y,rx:6,ry:5,fill:col||'#e9b824',stroke:'rgba(0,0,0,.25)','stroke-width':.6},g);
  E('ellipse',{cx:x-1.8,cy:y-1.8,rx:2.2,ry:1.3,fill:'#ffffff',opacity:.4},g);
  if(lbl) silk(g,x,y-8,lbl,7.5,{'text-anchor':'middle'}); }
function ce(g,x,y,r,lbl){ E('circle',{cx:x,cy:y+1.5,r:r+.5,fill:'rgba(0,0,0,.3)'},g);
  E('circle',{cx:x,cy:y,r,fill:'url(#gCap)',stroke:'#3d4247','stroke-width':1.2},g);
  E('path',{d:`M${x-r*.62},${y-r*.78} A${r*.98} ${r*.98} 0 0 0 ${x-r*.62},${y+r*.78}`,fill:'none',stroke:'#9aa1a8','stroke-width':r*.28},g);
  E('path',{d:`M${x-r*.42},${y} H${x+r*.42} M${x},${y-r*.42} V${y+r*.42}`,stroke:'#6a7076','stroke-width':1},g);
  if(lbl) silk(g,x,y+r+9,lbl,7.5,{'text-anchor':'middle'}); }
function icD(g,x,y,n,w,lbl,des){ const h=24;
  for(let i=0;i<n;i++){ const px=x+6+i*(w-12)/(n-1)-1.7; E('rect',{x:px,y:y-4.5,width:3.4,height:5,fill:'#cfd2d5'},g); E('rect',{x:px,y:y+h-.5,width:3.4,height:5,fill:'#cfd2d5'},g); }
  E('rect',{x:x,y:y+1.5,width:w,height:h,rx:2,fill:'rgba(0,0,0,.35)'},g);
  E('rect',{x,y,width:w,height:h,rx:2,fill:'url(#gIC)'},g);
  E('path',{d:`M${x},${y+h/2-4} A4 4 0 0 1 ${x},${y+h/2+4} Z`,fill:'#0c0d0e'},g);
  E('circle',{cx:x+7,cy:y+h-6,r:1.6,fill:'#2f3337'},g);
  T(g,x+w/2,y+h/2+3.5,lbl,{'text-anchor':'middle','font-size':8.5,fill:'#a7acb1'});
  if(des) silk(g,x,y-9,des,8); }
function to92(g,x,y,lbl){ E('path',{d:`M${x-7},${y+4} A8 8 0 1 1 ${x+7},${y+4} Z`,fill:'#1c1e20',stroke:'#3a3e42'},g); E('rect',{x:x-7,y:y+2,width:14,height:2.2,fill:'#2b2e31'},g); if(lbl) silk(g,x,y+14,lbl,7.5,{'text-anchor':'middle'}); }
function metalCan(g,x,y,r,lbl){ E('circle',{cx:x,cy:y+2,r:r+1,fill:'rgba(0,0,0,.3)'},g); E('circle',{cx:x,cy:y,r,fill:'url(#gMetal)',stroke:'#80868c','stroke-width':1.5},g);
  E('circle',{cx:x,cy:y,r:r*.62,fill:'none',stroke:'#9ea4a9','stroke-width':1},g); E('rect',{x:x+r*.7,y:y-2,width:5,height:4,fill:'#b7bcc1'},g); if(lbl) silk(g,x,y+r+11,lbl,8,{'text-anchor':'middle'}); }
function ift(g,x,y,slug,lbl){ E('rect',{x:x-12,y:y-10,width:24,height:24,rx:2,fill:'rgba(0,0,0,.3)'},g); E('rect',{x:x-12,y:y-12,width:24,height:24,rx:2,fill:'url(#gMetal)',stroke:'#80868c'},g);
  E('circle',{cx:x,cy:y,r:6.5,fill:slug||'#e5c84d',stroke:'rgba(0,0,0,.35)'},g); E('rect',{x:x-4,y:y-1,width:8,height:2,fill:'rgba(0,0,0,.55)'},g); if(lbl) silk(g,x,y+22,lbl,7.5,{'text-anchor':'middle'}); }
function led(g,x,y,col,lbl){ E('circle',{cx:x,cy:y,r:10,fill:col,opacity:.25},g); E('circle',{cx:x,cy:y,r:6,fill:col,stroke:'rgba(0,0,0,.3)'},g); E('circle',{cx:x-2,cy:y-2,r:1.8,fill:'#ffffff',opacity:.75},g); if(lbl) silk(g,x,y+17,lbl,8,{'text-anchor':'middle'}); }
function tpt(g,x,y,lbl,sid){
  const t=E('g',{class:sid?'clk':'',transform:`translate(${x},${y})`},g);
  if(sid){ t.setAttribute('tabindex',0); t.setAttribute('role','button'); t.setAttribute('aria-label','Test point '+lbl+' on '+sockName(sid)); E('circle',{class:'ring',r:9,fill:'none',stroke:'none'},t); }
  E('circle',{r:5,fill:'none',stroke:'#d9dcdf','stroke-width':2.6},t); E('circle',{r:5,fill:'none',stroke:'#8e9399','stroke-width':.6},t);
  silk(t,8,3,lbl,7.5);
  if(sid){ E('title',null,t).textContent='Test point '+lbl+' · '+sockName(sid); act(t,()=>clickTP(sid)); }
}
function arrowL(g,x1,y1,x2,y2){ E('line',{x1,y1,x2,y2,stroke:SILK,'stroke-width':1.3,'marker-end':'url(#arr)'},g); }
function trace(g,d){ E('path',{d,fill:'none',stroke:TRACE,'stroke-width':2.2,'stroke-linejoin':'round','stroke-linecap':'round',opacity:.85},g); }
function box(g,x,y,w,h,l1,l2){ E('rect',{x,y,width:w,height:h,fill:'none',stroke:SILK,'stroke-width':1.4},g);
  T(g,x+w/2,y+h/2-(l2?3:-4),l1,{'text-anchor':'middle','font-size':11,'font-weight':700,fill:SILK,'letter-spacing':.6});
  if(l2) T(g,x+w/2,y+h/2+11,l2,{'text-anchor':'middle','font-size':11,'font-weight':700,fill:SILK,'letter-spacing':.6}); }
function slideSw(g,x,y,label,fn,dkey){ const sg=E('g',{class:'clk',tabindex:0,role:'switch','aria-label':label,transform:`translate(${x},${y})`},g);
  E('rect',{class:'ring',x:-4,y:-4,width:62,height:28,rx:6,fill:'none',stroke:'none'},sg);
  E('rect',{x:0,y:0,width:54,height:20,rx:3,fill:'#1d1f22',stroke:'#5b6167'},sg); E('rect',{x:4,y:7,width:46,height:6,rx:3,fill:'#0f1011'},sg);
  dyn[dkey]=E('circle',{cx:10,cy:10,r:7,fill:'url(#gMetal)',stroke:'#6f757b'},sg); act(sg,fn); return sg; }

function buildBoard(){
  const svg=$('#board'); svg.innerHTML=''; seedR=5;
  const defs=E('defs',null,svg);
  const mk=E('marker',{id:'arr',viewBox:'0 0 10 10',refX:9,refY:5,markerWidth:7,markerHeight:7,orient:'auto-start-reverse'},defs);
  E('path',{d:'M0,0 L10,5 L0,10 z',fill:SILK},mk);
  const grad=(id,type,stops,attrs)=>{ const gr=E(type,Object.assign({id},attrs||{}),defs); for(const [o,c] of stops) E('stop',{offset:o,'stop-color':c},gr); };
  grad('wood','linearGradient',[[0,'#d8bd86'],[.35,'#e7d2a5'],[.7,'#dcc08b'],[1,'#cfb07a']],{x1:0,y1:0,x2:1,y2:.2});
  grad('pcb','linearGradient',[[0,'#13703f'],[.55,'#0f6337'],[1,'#0b5430']],{x1:0,y1:0,x2:1,y2:1});
  grad('gRed','radialGradient',[[0,'#ff6b6b'],[.55,'#d6232c'],[1,'#8c0f16']],{cx:.38,cy:.32,r:.75});
  grad('gMetal','radialGradient',[[0,'#f4f6f7'],[.6,'#bfc4c8'],[1,'#858b91']],{cx:.35,cy:.3,r:.8});
  grad('gBlue','linearGradient',[[0,'#4a86e8'],[1,'#1f4fa8']],{x1:0,y1:0,x2:1,y2:1});
  grad('gIC','linearGradient',[[0,'#2a2d30'],[1,'#141617']],{x1:0,y1:0,x2:0,y2:1});
  grad('gCap','radialGradient',[[0,'#3c4146'],[1,'#17191b']],{cx:.4,cy:.35,r:.8});
  grad('hinge','linearGradient',[[0,'#f1f3f4'],[.5,'#b5babf'],[1,'#e0e3e5']],{x1:0,y1:0,x2:0,y2:1});
  const fl=E('filter',{id:'glow',x:'-10%',y:'-10%',width:'120%',height:'120%'},defs); E('feGaussianBlur',{stdDeviation:3.2},fl);

  // wooden box, PCB, hinges and mounting screws
  E('rect',{x:0,y:0,width:1200,height:860,rx:12,fill:'url(#wood)'},svg);
  const grain=E('g',{stroke:'#b9985f',opacity:.35,fill:'none'},svg);
  for(let i=0;i<9;i++){ const y=3+i*1.4; E('path',{d:`M0,${y} C300,${y+1.2} 600,${y-1} 1200,${y+.6}`},grain); E('path',{d:`M0,${846+i*1.4} C400,${847+i*1.4} 800,${845+i*1.4} 1200,${846.5+i*1.4}`},grain); }
  E('rect',{x:13,y:13,width:1174,height:834,rx:3,fill:'rgba(0,0,0,.35)'},svg);
  E('rect',{x:16,y:16,width:1168,height:828,rx:3,fill:'url(#pcb)'},svg);
  for(const hx of [150,980]){ E('rect',{x:hx,y:0,width:76,height:15,rx:2,fill:'url(#hinge)',stroke:'#8a9095'},svg); for(let k=0;k<3;k++) E('circle',{cx:hx+14+k*24,cy:7.5,r:2.6,fill:'#9aa0a5',stroke:'#6d7378'},svg); }
  for(const [x,y] of [[30,30],[1170,30],[30,830],[1170,830]]){ E('circle',{cx:x,cy:y,r:8,fill:'url(#gMetal)',stroke:'#5f656a'},svg); E('path',{d:`M${x-4},${y} H${x+4} M${x},${y-4} V${y+4}`,stroke:'#4d5257','stroke-width':1.6},svg); }

  // title strip (reads along the top edge of the real board)
  const tg=E('g',{'font-family':MONO},svg);
  E('rect',{x:46,y:28,width:76,height:20,fill:'none',stroke:SILK,'stroke-width':1.2},tg); T(tg,84,42,'TOPSIDE',{'text-anchor':'middle','font-size':10,'font-weight':700,fill:SILK});
  T(tg,452,55,'AMPLITUDE MODULATION AND DEMODULATION',{'text-anchor':'middle','font-size':24,'font-weight':700,fill:SILK,'letter-spacing':2});
  E('line',{x1:20,y1:70,x2:800,y2:70,stroke:SILK,'stroke-width':1.6},tg);

  const gB=E('g',{'font-family':MONO},svg);
  for(const b of BLK) drawBlock(b,gB);
  gW=E('g',null,svg);
  pendLine=E('path',{fill:'none',stroke:'#ffffff','stroke-width':3,'stroke-dasharray':'7 6','pointer-events':'none',opacity:0.9},svg);
  gS=E('g',{'font-family':MONO},svg);
  for(const id in SOCK) drawSocket(id,gS);
  gP=E('g',{'pointer-events':'none','font-family':MONO},svg);
  svg.addEventListener('pointermove',e=>{ if(!S.pending){pendLine.setAttribute('d','');return;}
    const p=svgPt(e); const a=POS[S.pending]; pendLine.setAttribute('d',`M${a[0]},${a[1]} L${p.x},${p.y}`); });
  svg.addEventListener('pointerleave',()=>pendLine.setAttribute('d',''));
}
function svgPt(e){const svg=$('#board'); const p=svg.createSVGPoint(); p.x=e.clientX; p.y=e.clientY; return p.matrixTransform(svg.getScreenCTM().inverse());}
function clickTP(sid){ if(S.mode==='p1'||S.mode==='p2'){ clickSocket(sid); return; } hint('Test points take scope probes. Choose <b>Probe CH1</b> or <b>Probe CH2</b>, then click the test point.'); }

function drawBlock(b,root){
  const g=E('g',{transform:`translate(${b.x},${b.y})`},root);
  E('rect',{x:0,y:0,width:b.w,height:b.h,fill:'none',stroke:SILK,'stroke-width':1.5,'stroke-opacity':.9},g);
  const titled=!b.bm&&b.id!=='dem'&&b.id!=='pwr';
  if(titled) T(g,12,22,b.t,{'font-size':b.w<200?11:13,'font-weight':700,fill:SILK,'letter-spacing':1});
  const D=DECOR[b.bm?'bm':b.id]; if(D) D(g,b);
  for(const [k,l,x,y,v] of b.kn) drawKnob(g,k,l,x,y,v);
  for(const [id,,,,,des] of b.sk){ const s=SOCK[id]; if(s.tp) tpt(g,s.tp[0]-b.x,s.tp[1]-b.y,'TP'+(Object.keys(SOCK).indexOf(id)+1),id); }
}
const DECOR={
  afg(g){ E('rect',{x:24,y:34,width:236,height:208,fill:'none',stroke:SILK,'stroke-opacity':.7,'stroke-width':1.1},g);
    trace(g,'M70,98 V130 H150 V104 H180'); trace(g,'M100,72 H128 M150,130 V188 H180'); trace(g,'M212,104 H260 V118 H300'); trace(g,'M212,188 H250 V130');
    icD(g,44,60,4,52,'8038','U2'); rz(g,140,56,0,'R16'); rz(g,140,74,0,'R17'); rz(g,140,92,0,'R18'); cc(g,72,120,'#e9b824','C12'); cc(g,96,120,'#3b7dd8','C13'); rz(g,240,214,0,'R19');
    silk(g,40,178,'WAVE (SIM)',8); dyn.wave={};
    const icons={sine:'M3,9 C6,1 9,1 11,9 S16,17 19,9',square:'M3,13 V5 H11 V13 H19 V5',tri:'M3,13 L7,5 L11,13 L15,5 L19,13'};
    Object.keys(icons).forEach((w,i)=>{ const sg=E('g',{class:'clk',tabindex:0,role:'button','aria-label':'AF waveform '+w,transform:`translate(${40+i*34},186)`},g);
      E('rect',{class:'ring',x:-3,y:-3,width:34,height:26,rx:4,fill:'none',stroke:'none'},sg);
      dyn.wave[w]=E('rect',{x:0,y:0,width:28,height:20,rx:2,fill:'#1d1f22',stroke:'#5b6167'},sg);
      E('path',{d:icons[w],transform:'translate(3,1)',fill:'none',stroke:'#fff','stroke-width':1.6},sg);
      act(sg,()=>{S.ctl.afWave=w; update();}); }); },
  rfg(g){ trace(g,'M84,74 H170 M250,70 H290 V110 H300'); trace(g,'M60,130 V168 M210,118 V150 H140 V176'); trace(g,'M160,192 H300 V126');
    const dg=E('g',{transform:'translate(24,40)'},g);
    E('rect',{x:0,y:0,width:120,height:52,rx:2,fill:'#e0405a',stroke:'#9e2238'},dg); silk(dg,4,-4,'ON  SW1',8);
    dyn.rfdip=[];
    for(let i=0;i<4;i++){ const sg=E('g',{class:'clk',tabindex:0,role:'button','aria-label':'RF frequency '+RF_LBL[i],transform:`translate(${10+i*28},8)`},dg);
      E('rect',{class:'ring',x:-3,y:-3,width:20,height:42,rx:3,fill:'none',stroke:'none'},sg);
      E('rect',{x:0,y:0,width:14,height:36,rx:1.5,fill:'#f4f4f4'},sg);
      dyn.rfdip.push(E('rect',{x:1.5,y:2,width:11,height:14,rx:1,fill:'#2b2b2b'},sg));
      T(dg,17+i*28,66,RF_LBL[i],{'text-anchor':'middle','font-size':10,'font-weight':600,fill:SILK});
      act(sg,()=>{S.ctl.rfSel=i; update();}); }
    icD(g,170,58,7,80,'XR2206','U1'); ['C2','C3','C4','C5'].forEach((c,i)=>cc(g,182+i*20,120,i%2?'#3b7dd8':'#e9b824',c));
    rz(g,40,150,1,'R1'); rz(g,64,150,1,'R2'); rz(g,88,150,1,'R3'); to92(g,232,188,'Q1'); ce(g,262,226,10,'C8'); },
  pre(g){ trace(g,'M66,84 V120 H150 M200,98 H240 V110 H300'); trace(g,'M100,72 H150 M175,98 V150 H230'); trace(g,'M60,206 H120 V178');
    E('rect',{x:30,y:52,width:34,height:30,rx:3,fill:'#141516',stroke:'#3b3f43'},g); E('circle',{cx:47,cy:67,r:8,fill:'#2b2e31',stroke:'#9aa0a5','stroke-width':2},g); E('circle',{cx:47,cy:67,r:3,fill:'#0b0c0d'},g);
    silk(g,72,64,'MIC IN',9); silk(g,72,76,'J1',7.5);
    slideSw(g,30,100,'Microphone',()=>{S.ctl.mic=!S.ctl.mic; update();},'mic'); dyn.micT=T(g,92,115,'MIC ON',{'font-size':10,fill:SILK,'font-weight':600});
    icD(g,150,72,4,52,'TL072','U5'); rz(g,230,60,0,'R77'); rz(g,230,78,0,'R76'); rz(g,112,150,1,'R81'); rz(g,136,150,1,'R83'); rz(g,160,150,1,'R84');
    cc(g,200,140,'#e9b824','C51'); cc(g,222,140,'#e9b824','C52'); cc(g,244,140,'#3b7dd8','C53'); ce(g,258,198,10,'C56');
    tpt(g,48,206,'GND1',null); },
  bm(g,b){ const n=b.bm;
    trace(g,'M66,112 H140 V96 H222 V82'); trace(g,'M150,206 H190 V82 M242,82 V96 H300'); trace(g,'M320,139 H340 M300,56 H360 V112'); trace(g,'M168,78 V96 H196');
    box(g,210,108,110,62,'BALANCED','MODULATOR '+n);
    arrowL(g,84,114,208,132); arrowL(g,150,188,236,172); arrowL(g,322,139,352,132);
    icD(g,216,30,7,84,'MC1496','U'+(n+5)); rz(g,330,40,0,'R'+(40+n*3)); rz(g,330,58,0,'R'+(41+n*3)); rz(g,250,200,1,'R'+(42+n*3)); rz(g,272,200,1,'R'+(60+n)); rz(g,294,200,1,'R'+(70+n));
    cc(g,196,90,'#e9b824','C'+(15+n)); cc(g,330,92,'#3b7dd8','C'+(20+n)); cc(g,318,226,'#e9b824','C'+(24+n)); ce(g,250,234,9,''); },
  pwr(g){ trace(g,'M33,52 V76 H75 M105,62 V76 H140'); trace(g,'M200,48 V76 H340 V60');
    E('rect',{x:20,y:12,width:26,height:10,fill:'url(#gMetal)',stroke:'#7c8288'},g); E('circle',{cx:33,cy:17,r:2.6,fill:'#5d6368'},g);
    E('rect',{x:20,y:22,width:26,height:24,fill:'#141516'},g); T(g,33,37,'7805',{'text-anchor':'middle','font-size':7,fill:'#a7acb1'});
    for(let k=0;k<3;k++) E('rect',{x:25+k*7,y:46,width:2.5,height:8,fill:'#cfd2d5'},g); silk(g,22,68,'U12',7.5);
    ce(g,78,40,13,'C59'); ce(g,110,40,13,'C60');
    led(g,148,36,'#43e06a','+12V'); led(g,172,36,'#f4d23a','−12V'); led(g,196,36,'#ff4a3d','+5V');
    const dg=E('g',{transform:'translate(214,22)'},g); silk(dg,0,-4,'FAULT SW2',8);
    E('rect',{x:0,y:0,width:120,height:40,rx:2,fill:'#2f6bd1',stroke:'#1c4590'},dg); dyn.fault=[];
    for(let i=0;i<8;i++){ const sg=E('g',{class:'clk',tabindex:0,role:'switch','aria-label':'Fault switch '+(i+1),transform:`translate(${6+i*14},5)`},dg);
      E('rect',{class:'ring',x:-2,y:-2,width:14,height:34,rx:2,fill:'none',stroke:'none'},sg);
      E('rect',{x:0,y:0,width:10,height:30,rx:1.5,fill:'#f4f4f4'},sg);
      dyn.fault.push(E('rect',{x:1,y:15,width:8,height:13,rx:1,fill:'#2b2b2b'},sg));
      T(dg,11+i*14,52,String(i+1),{'text-anchor':'middle','font-size':8,fill:SILK});
      act(sg,()=>{ if(S.hidden!=null) return; S.faults[i]=!S.faults[i]; update(); }); }
    dyn.cover=E('g',{},dg); E('rect',{x:-3,y:-2,width:126,height:44,rx:3,fill:'#20262a',stroke:'#e7b51c','stroke-dasharray':'4 3'},dyn.cover);
    T(dyn.cover,60,25,'HIDDEN FAULT',{'text-anchor':'middle','font-size':10,'font-weight':700,fill:'#e7b51c'});
    E('rect',{x:344,y:16,width:28,height:46,rx:2,fill:'#f2f0ea',stroke:'#b9b5aa'},g);
    for(let r=0;r<3;r++) for(let c=0;c<2;c++) E('rect',{x:349+c*11,y:21+r*13,width:7,height:9,rx:1,fill:'#cfcabb'},g);
    silk(g,346,76,'J2',7.5); },
  dem(g){ trace(g,'M44,78 H90 M152,150 H200 V138 H232 M316,128 H330 V92'); trace(g,'M212,83 H242 V115 M300,70 V115');
    box(g,92,56,120,52,'BALANCED','DEMODULATOR'); arrowL(g,62,80,90,82); arrowL(g,152,134,152,110); arrowL(g,214,82,322,80);
    icD(g,232,124,7,84,'MC1496','U9'); rz(g,250,100,1,'R33'); rz(g,274,100,1,'R34'); rz(g,298,100,1,'R35'); cc(g,110,132,'#e9b824','C27'); cc(g,240,164,'#3b7dd8','C28'); },
  ssb(g){ trace(g,'M34,64 V98 M104,64 V40 H222 V64 M104,132 V156 H222 V132'); trace(g,'M298,98 H324');
    arrowL(g,52,64,84,64); arrowL(g,52,132,84,132);
    arrowL(g,240,68,266,86); arrowL(g,240,128,266,108);
    E('circle',{cx:282,cy:96,r:16,fill:'none',stroke:SILK,'stroke-width':1.5},g);
    E('line',{x1:271,y1:85,x2:293,y2:107,stroke:SILK,'stroke-width':1.5},g); E('line',{x1:293,y1:85,x2:271,y2:107,stroke:SILK,'stroke-width':1.5},g);
    arrowL(g,299,97,322,98);
    slideSw(g,258,128,'Summer mode',()=>{S.ctl.ssbMode*=-1; update();},'ssbSw');
    silk(g,256,160,'A+B',8.5,{'text-anchor':'middle'}); silk(g,318,160,'A−B',8.5,{'text-anchor':'middle'});
    icD(g,250,24,4,52,'TL072','U11'); rz(g,340,40,1,''); },
  rpa(g){ trace(g,'M28,150 H60 M130,150 H162'); E('rect',{x:52,y:38,width:86,height:80,fill:'none',stroke:SILK,'stroke-width':1.3},g); silk(g,56,112,'G2',8);
    metalCan(g,95,76,20,''); rz(g,95,140,0,'R52'); rz(g,95,160,0,'R53'); },
  rpre(g){ trace(g,'M28,150 H70 V92 M120,92 V150 H162'); to92(g,64,78,'Q3'); ift(g,124,76,'#e5c84d','T2'); rz(g,94,140,0,'R47'); rz(g,94,160,0,'R48'); cc(g,164,100,'#e9b824','C40'); },
  b455(g){ trace(g,'M28,72 H83 M107,72 H162'); for(let k=0;k<3;k++) E('path',{d:`M${126+k*7},10 q6,8 0,16`,fill:'none',stroke:SILK,'stroke-width':1.2},g);
    ift(g,95,70,'#f1d64f','T3'); cc(g,60,96,'#e9b824','C37'); to92(g,138,92,''); },
  b1m(g){ trace(g,'M28,72 H83 M107,72 H162'); for(let k=0;k<3;k++) E('path',{d:`M${110+k*7},10 q6,8 0,16`,fill:'none',stroke:SILK,'stroke-width':1.2},g);
    ift(g,95,70,'#e86a3c','T4'); cc(g,60,96,'#3b7dd8','C39'); to92(g,138,92,''); },
  apa(g){ trace(g,'M32,58 H70 M116,58 H136 M164,58 H190 M240,58 H272 M290,58 H320');
    icD(g,68,44,4,48,'LM386','U13'); ce(g,204,52,11,'C47'); ce(g,232,52,11,'C48');
    const sg=E('g',{class:'clk',tabindex:0,role:'switch','aria-label':'Speaker',transform:'translate(330,56)'},g);
    E('rect',{class:'ring',x:-20,y:-17,width:40,height:34,rx:4,fill:'none',stroke:'none'},sg);
    E('rect',{x:-16,y:-13,width:32,height:26,rx:2,fill:'#141516',stroke:'#3b3f43'},sg); E('circle',{r:7,fill:'#2b2e31',stroke:'#9aa0a5','stroke-width':2},sg); E('circle',{r:2.6,fill:'#0b0c0d'},sg);
    dyn.waves=E('g',{fill:'none',stroke:'#f4c430','stroke-width':2},sg); E('path',{d:'M21,-8 Q26,0 21,8'},dyn.waves); E('path',{d:'M27,-13 Q34,0 27,13'},dyn.waves);
    E('title',null,sg).textContent='Speaker output (click to listen)'; act(sg,toggleAudio);
    silk(g,330,86,'SPEAKER',8,{'text-anchor':'middle'}); },
};
function act(el,fn){ el.addEventListener('click',e=>{e.stopPropagation(); fn();}); el.addEventListener('keydown',e=>{ if(e.key==='Enter'||e.key===' '){e.preventDefault(); e.stopPropagation(); fn();} }); }
function drawKnob(g,k,l,x,y,showVal){
  const kg=E('g',{class:'knob',tabindex:0,role:'slider','aria-label':KN[k].l,transform:`translate(${x},${y})`},g);
  E('rect',{class:'ring',x:-19,y:-19,width:38,height:38,rx:5,fill:'none',stroke:'none'},kg);
  E('rect',{x:-14,y:-12,width:30,height:30,rx:2,fill:'rgba(0,0,0,.35)'},kg);
  E('rect',{x:-15,y:-15,width:30,height:30,rx:2,fill:'url(#gBlue)',stroke:'#173f86','stroke-width':1.2},kg);
  E('circle',{cx:11,cy:11,r:1.6,fill:'#cfd2d5'},kg);
  E('circle',{r:10,fill:'#e8edf2',stroke:'#9fb1c8'},kg);
  const rot=E('g',null,kg); E('rect',{x:-1.6,y:-7.5,width:3.2,height:15,fill:'#3a4a60'},rot); E('rect',{x:-7.5,y:-1.6,width:15,height:3.2,fill:'#3a4a60'},rot);
  E('circle',{cx:0,cy:-7.5,r:1.6,fill:'#e2382f'},rot);
  T(g,x,y+29,l,{'text-anchor':'middle','font-size':9,'font-weight':600,fill:SILK});
  const vt=showVal?T(g,x,y+41,'',{'text-anchor':'middle','font-size':9,fill:'#c7ecd3'}):{set textContent(v){}};
  knobEls[k]={rot,vt,kg};
  let drag=null;
  kg.addEventListener('pointerdown',e=>{ e.preventDefault(); kg.setPointerCapture(e.pointerId); drag={y:e.clientY,n:norm(k,S.ctl[k])}; kg.focus(); });
  kg.addEventListener('pointermove',e=>{ if(!drag) return; S.ctl[k]=denorm(k,drag.n+(drag.y-e.clientY)/160); update(); });
  kg.addEventListener('pointerup',()=>{drag=null;}); kg.addEventListener('pointercancel',()=>{drag=null;});
  kg.addEventListener('keydown',e=>{ const d={ArrowUp:1,ArrowRight:1,ArrowDown:-1,ArrowLeft:-1}[e.key]; if(!d) return; e.preventDefault(); S.ctl[k]=denorm(k,norm(k,S.ctl[k])+d*0.01*(e.shiftKey?5:1)); update(); });
  kg.addEventListener('wheel',e=>{ e.preventDefault(); S.ctl[k]=denorm(k,norm(k,S.ctl[k])-Math.sign(e.deltaY)*0.01); update(); },{passive:false});
  E('title',null,kg).textContent=KN[k].l+' (drag up or down)';
}
function drawSocket(id,root){
  const s=SOCK[id], [x,y]=POS[id];
  const g=E('g',{class:'sock',tabindex:0,role:'button','aria-label':sockName(id)+(s.io==='o'?' (output)':' (input)'),'data-id':id,transform:`translate(${x},${y})`},root);
  if(s.io==='o') E('rect',{x:-18,y:-18,width:36,height:36,fill:'none',stroke:SILK,'stroke-width':1.2,'stroke-opacity':.85},g);
  const pend=E('circle',{r:21,fill:'none',stroke:'#ffffff','stroke-width':2,'stroke-dasharray':'4 3',opacity:0},g);
  E('circle',{class:'ring',r:16,fill:'none',stroke:'none'},g);
  E('circle',{cy:2.2,r:13.5,fill:'rgba(0,0,0,.35)'},g);
  E('circle',{r:13,fill:'url(#gRed)',stroke:'#7d0e14','stroke-width':1.3},g);
  E('circle',{r:7,fill:'url(#gMetal)',stroke:'#6f757b','stroke-width':.8},g);
  const hole=E('circle',{r:4,fill:'#1a1c1e'},g);
  const ly= s.lp==='a'?-24: s.lp==='l'?4:31;
  T(g,s.lp==='l'?-18:0,ly,s.l,{'text-anchor':s.lp==='l'?'end':'middle','font-size':9.5,'font-weight':600,fill:SILK,'letter-spacing':.3});
  if(s.des) T(g,15,-12,s.des,{'font-size':7.5,fill:SILK,opacity:.75});
  E('title',null,g).textContent=sockName(id)+(s.io==='o'?' · output':' · input');
  dyn['h_'+id]=hole; dyn['p_'+id]=pend;
  act(g,()=>clickSocket(id));
}
function cordPath(a,b){ const dx=Math.abs(b[0]-a[0]); const sag=50+dx*0.18+Math.abs(b[1]-a[1])*0.1; return `M${a[0]},${a[1]} C${a[0]},${a[1]+sag} ${b[0]},${b[1]+sag} ${b[0]},${b[1]}`; }
// Signal flow on a patch cord: glowing pulses travel from the output socket to the input socket.
// Amber = audio-band signal, cyan = RF; a cord with no signal stays dark. Phase is tied to the clock so redraws don't restart it.
function flowOn(d,s){
  let amax=0,fdom=0; for(const c of s) if(c.f>0&&c.a>amax){amax=c.a; fdom=c.f;}
  if(amax<1e-4) return;
  const rf=fdom>20000, col=rf?'#7df9ff':'#ffd84d', lvl=Math.min(1,0.45+Math.log10(amax*1000+1)/3.2);
  const dur=rf?0.45:0.9, delay='-'+((performance.now()/1000)%dur).toFixed(3)+'s';
  if(PERF.iv<100){ const gl=E('path',{d,class:'flow-glow',fill:'none',stroke:col,'stroke-width':10,'stroke-opacity':(0.3*lvl).toFixed(2),filter:'url(#glow)','pointer-events':'none'},gW); gl.style.animationDelay='-'+((performance.now()/1000)%1.6).toFixed(3)+'s'; }
  const p=E('path',{d,class:'flow '+(rf?'rf':'af'),fill:'none',stroke:col,color:col,'stroke-width':2.8,'stroke-linecap':'round','stroke-dasharray':rf?'2 14':'10 22',opacity:lvl.toFixed(2),'pointer-events':'none'},gW);
  p.style.animationDelay=delay;
}
function updBoard(){
  gW.innerHTML='';
  for(const w of S.wires){ const d=cordPath(POS[w.from],POS[w.to]);
    E('path',{d,fill:'none',stroke:'rgba(0,0,0,0.35)','stroke-width':9,'pointer-events':'none',transform:'translate(1.5,3)'},gW);
    E('path',{d,fill:'none',stroke:w.c,'stroke-width':5.5,'stroke-linecap':'round','pointer-events':'none'},gW);
    E('path',{d,fill:'none',stroke:'rgba(255,255,255,0.3)','stroke-width':1.5,'pointer-events':'none',transform:'translate(-1,-1)'},gW);
    flowOn(d,sig(w.from));
    const hit=E('path',{d,fill:'none',stroke:'transparent','stroke-width':14,class:'cordhit','pointer-events':'stroke'},gW);
    E('title',null,hit).textContent=sockName(w.from)+' → '+sockName(w.to)+' (click to remove)';
    hit.addEventListener('click',e=>{ e.stopPropagation(); if(S.mode!=='patch') return; S.wires=S.wires.filter(x=>x!==w); hint('Cord removed: '+sockName(w.from)+' → '+sockName(w.to)); update(); });
  }
  for(const id in SOCK){ const w=S.wires.find(w=>w.from===id||w.to===id); dyn['h_'+id].setAttribute('fill',w?w.c:'#1a1c1e'); dyn['p_'+id].setAttribute('opacity',S.pending===id?1:0); }
  if(!S.pending) pendLine.setAttribute('d','');
  gP.innerHTML='';
  for(const ch of [1,2]){ const id=S.probes[ch]; if(!id||!POS[id]) continue; if(ch===2&&!S.scope.ch2&&!S.scope.xy) continue;
    const [x,y]=POS[id]; const both=S.probes[1]===S.probes[2]; const ox=both?(ch===1?-16:16):0, fx=x+ox+(ch===1?-24:12), fy=y-40;
    const col=ch===1?'#f1cc2a':'#2fd0e6';
    E('path',{d:`M${x+ox*0.4},${y-10} L${fx+6},${fy+16}`,stroke:col,'stroke-width':2.5},gP);
    E('rect',{x:fx-6,y:fy,width:24,height:17,rx:3,fill:col,stroke:'#111','stroke-width':1},gP);
    T(gP,fx+6,fy+13,'CH'+ch,{'text-anchor':'middle','font-size':9.5,'font-weight':700,fill:'#111'});
  }
  for(const k in knobEls){ const n=norm(k,S.ctl[k]); knobEls[k].rot.setAttribute('transform',`rotate(${-135+270*n})`); knobEls[k].vt.textContent=fmtK(k,S.ctl[k]);
    knobEls[k].kg.setAttribute('aria-valuetext',fmtK(k,S.ctl[k])); }
  dyn.rfdip.forEach((k,i)=>k.setAttribute('y',i===S.ctl.rfSel?2:20));
  dyn.fault.forEach((k,i)=>{k.setAttribute('y',S.faults[i]?2:15);});
  for(const w in dyn.wave) dyn.wave[w].setAttribute('fill',S.ctl.afWave===w?'#c9252c':'#1d1f22');
  dyn.cover.style.display=S.hidden!=null?'':'none';
  dyn.mic.setAttribute('cx',S.ctl.mic?44:10); dyn.micT.textContent=S.ctl.mic?'MIC ON':'MIC OFF';
  dyn.ssbSw.setAttribute('cx',S.ctl.ssbMode>0?10:46);
  dyn.waves.style.display=AUD.on?'':'none';
}
function clickSocket(id){
  if(S.mode==='p1'||S.mode==='p2'){ const ch=S.mode==='p1'?1:2; S.probes[ch]=id; if(ch===2) S.scope.ch2=true; hint(`CH${ch} probe on <b>${sockName(id)}</b>.`); update(); return; }
  if(!S.pending){ S.pending=id; hint(`Cord from <b>${sockName(id)}</b>. Now click ${SOCK[id].io==='o'?'an input':'an output'} socket. Click it again to cancel.`); update(); return; }
  if(S.pending===id){ S.pending=null; hint('Cord cancelled.'); update(); return; }
  const a=SOCK[S.pending], b=SOCK[id];
  if(a.io===b.io){ hint(`Both sockets are ${a.io==='o'?'outputs':'inputs'}. Connect an output (square frame) to an input.`); S.pending=null; update(); return; }
  const from=a.io==='o'?a.id:b.id, to=a.io==='o'?b.id:a.id;
  addWire(from,to); S.pending=null; hint(`Connected <b>${sockName(from)} → ${sockName(to)}</b>.`); update();
}
function addWire(from,to){ if(S.wires.some(w=>w.from===from&&w.to===to)) return; S.wires=S.wires.filter(w=>w.to!==to); S.wires.push({from,to,c:CORDS[S.cordN++%CORDS.length]}); }
let hintT=0;
function hint(html){ $('#hint').innerHTML=html; clearTimeout(hintT); hintT=setTimeout(defaultHint,6000); }
function defaultHint(){ $('#hint').innerHTML= S.mode==='patch' ? 'Click an <b>output</b> (square frame), then an <b>input</b>. Click a cord to remove it.' : `Click any socket to move the <b>CH${S.mode==='p1'?1:2}</b> probe there.`; }

/* ---------------- oscilloscope ---------------- */
function prep(s){ return {w:Float64Array.from(s,c=>TAU*c.f),a:Float64Array.from(s,c=>c.a),p:Float64Array.from(s,c=>c.p),fmax:s.reduce((m,c)=>Math.max(m,c.f),0)}; }
function ev(P,t){ let v=0; const n=P.w.length; for(let i=0;i<n;i++) v+=P.a[i]*Math.cos(P.w[i]*t+P.p[i]); return v; }
function fitCanvas(cv){ const r=cv.getBoundingClientRect(), d=Math.min(window.devicePixelRatio||1,2); const w=Math.max(10,Math.round(r.width*d)), h=Math.max(10,Math.round(r.height*d)); if(cv.width!==w||cv.height!==h){cv.width=w;cv.height=h;} return {w,h,d}; }
function grid(ctx,w,h,d,nx,ny){
  ctx.fillStyle='#07110c'; ctx.fillRect(0,0,w,h);
  const rg=ctx.createRadialGradient(w/2,h/2,0,w/2,h/2,w*0.7); rg.addColorStop(0,'rgba(40,90,60,.18)'); rg.addColorStop(1,'rgba(0,0,0,0)'); ctx.fillStyle=rg; ctx.fillRect(0,0,w,h);
  ctx.strokeStyle='#1d3829'; ctx.lineWidth=1*d;
  for(let i=0;i<=nx;i++){ const x=Math.round(i*w/nx)+.5; ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,h); ctx.stroke(); }
  for(let j=0;j<=ny;j++){ const y=Math.round(j*h/ny)+.5; ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(w,y); ctx.stroke(); }
  ctx.strokeStyle='#2d5440';
  for(let i=0;i<=nx*5;i++){ const x=i*w/(nx*5); ctx.beginPath(); ctx.moveTo(x,h/2-3*d); ctx.lineTo(x,h/2+3*d); ctx.stroke(); }
  for(let j=0;j<=ny*5;j++){ const y=j*h/(ny*5); ctx.beginPath(); ctx.moveTo(w/2-3*d,y); ctx.lineTo(w/2+3*d,y); ctx.stroke(); }
}
function strokeGlow(ctx,path,col,d){ ctx.save(); ctx.strokeStyle=col; ctx.globalAlpha=.2; ctx.lineWidth=4.5*d; ctx.stroke(path); ctx.globalAlpha=1; ctx.lineWidth=1.3*d; ctx.stroke(path); ctx.restore(); }
let scopeP=null;
function drawScope(live){
  const cv=$('#scope'), {w,h,d}=fitCanvas(cv), ctx=cv.getContext('2d');
  grid(ctx,w,h,d,10,8);
  const sc=S.scope, T10=10*sc.tb, dy=h/8, t0=sc.trig==='free'?S.t0:0;
  const P1=prep(sig(S.probes[1])), P2=prep(sig(S.probes[2])); scopeP=[P1,P2];
  const jit=live?()=>(Math.random()-.5)*0.9*d:()=>0;
  if(sc.xy){
    ctx.fillStyle='#9ff3c0';
    const N=7000, dx=w/10; let seed=1;
    for(let i=0;i<N;i++){ seed=(seed*16807)%2147483647; const t=seed/2147483647*Math.max(T10,1e-3);
      const x=w/2+(ev(P1,t)/sc.v1)*dx, y=h/2-(ev(P2,t)/sc.v2)*dy;
      if(x>=0&&x<=w&&y>=0&&y<=h) ctx.fillRect(x-.8*d,y-.8*d,1.6*d,1.6*d); }
    label(ctx,d,w,h,[[`X: CH1 ${fVd(sc.v1)}/div`,'#f1cc2a'],[`Y: CH2 ${fVd(sc.v2)}/div`,'#2fd0e6'],['XY mode','#c9d6cf']]);
    updCursorRead(); return;
  }
  const chans=[[P1,sc.v1,sc.pos1,'#f1cc2a',1]]; if(sc.ch2) chans.push([P2,sc.v2,sc.pos2,'#2fd0e6',2]);
  const cols=Math.min(w,PERF.cols);
  for(const [P,vd,pos,col] of chans){
    const yOf=v=>Math.max(-4,Math.min(h+4,h/2-(v/vd+pos)*dy));
    const dt=T10/cols, path=new Path2D();
    if(P.w.length===0){ for(let i=0;i<=cols;i+=4){ const x=i*w/cols, y=yOf(0)+jit(); i?path.lineTo(x,y):path.moveTo(x,y);} }
    else if(P.fmax*dt<0.3){ for(let i=0;i<=cols;i++){ const x=i*w/cols, y=yOf(ev(P,t0+i*dt))+jit(); i?path.lineTo(x,y):path.moveTo(x,y);} }
    else { const Sn=PERF.sn;
      for(let i=0;i<cols;i++){ let mn=Infinity,mx=-Infinity; for(let k=0;k<Sn;k++){ const fr=((k+((i*0.618034+k*0.414214)%1))/Sn); const v=ev(P,t0+(i+fr)*dt); if(v<mn)mn=v; if(v>mx)mx=v; }
        const x=(i+.5)*w/cols; path.moveTo(x,yOf(mx)+jit()); path.lineTo(x,yOf(mn)+jit()); } }
    strokeGlow(ctx,path,col,d);
    ctx.fillStyle=col; const gy=Math.max(6*d,Math.min(h-6*d,h/2-pos*dy)); ctx.beginPath(); ctx.moveTo(0,gy-5*d); ctx.lineTo(8*d,gy); ctx.lineTo(0,gy+5*d); ctx.fill();
  }
  if(sc.cur){ ctx.save(); ctx.setLineDash([5*d,4*d]); ctx.strokeStyle='#ff8a5c'; ctx.lineWidth=1.2*d;
    for(const [c,n] of [[sc.c1,'A'],[sc.c2,'B']]){ const x=c*w; ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,h); ctx.stroke();
      ctx.fillStyle='#ff8a5c'; ctx.font=`600 ${11*d}px JetBrains Mono, monospace`; ctx.fillText(n,x+4*d,14*d); } ctx.restore(); }
  if(sc.trig==='sync'){ ctx.fillStyle='#ff8a5c'; ctx.beginPath(); ctx.moveTo(w/2-5*d,0); ctx.lineTo(w/2+5*d,0); ctx.lineTo(w/2,7*d); ctx.fill(); }
  const L=[[`CH1 ${fVd(sc.v1)}/div`,'#f1cc2a']]; if(sc.ch2) L.push([`CH2 ${fVd(sc.v2)}/div`,'#2fd0e6']); L.push([`${fTB(sc.tb)}/div`,'#c9d6cf']); L.push([sc.run?(sc.trig==='sync'?'TRIG’D':'AUTO'):'STOP',sc.run?'#7cf0a0':'#ff6b6b']);
  label(ctx,d,w,h,L);
  updCursorRead();
}
function updCursorRead(){
  const el=$('#curRead'), sc=S.scope; el.hidden=!sc.cur||sc.xy; if(el.hidden||!scopeP) return;
  const T10=10*sc.tb, t0=sc.trig==='free'?S.t0:0, ta=sc.c1*T10, tb=sc.c2*T10, dt=Math.abs(tb-ta);
  const [P1,P2]=scopeP; const va1=ev(P1,t0+ta), vb1=ev(P1,t0+tb), va2=ev(P2,t0+ta), vb2=ev(P2,t0+tb);
  el.innerHTML=`<span><b>A</b>${fT(ta)}</span><span><b>B</b>${fT(tb)}</span><span><b>ΔT</b>${fT(dt)}</span><span><b>1/ΔT</b>${dt>0?fHz(1/dt):'—'}</span><span><b>CH1 ΔV</b>${(vb1-va1).toFixed(3)} V</span><span><b>CH2 ΔV</b>${(vb2-va2).toFixed(3)} V</span>`;
}
function label(ctx,d,w,h,items){
  ctx.font=`${11*d}px JetBrains Mono, Consolas, monospace`; ctx.textBaseline='bottom';
  let x=8*d; for(const [t,c] of items){ ctx.fillStyle='rgba(7,17,12,.78)'; const tw=ctx.measureText(t).width; ctx.fillRect(x-3*d,h-19*d,tw+6*d,16*d); ctx.fillStyle=c; ctx.fillText(t,x,h-5*d); x+=tw+16*d; }
  ctx.textBaseline='alphabetic';
}

/* ---------------- spectrum analyzer ---------------- */
function specRange(s){
  let v=S.spec.view; const rf=RF_OPTS[S.ctl.rfSel];
  if(v==='auto'){ const a=analyze(s);
    if(a.isRF){ const spread=Math.max(0,...s.filter(c=>c.a>1e-5&&Math.abs(c.f-a.fc)<30000).map(c=>Math.abs(c.f-a.fc))); v= spread<4400?'car5':'car25'; return rangeOf(v,a.fc); }
    v= Math.max(0,...s.filter(c=>c.a>1e-5).map(c=>c.f))>9500?'car25x':'base'; if(v==='car25x') return [0,25000,'0 – 25 kHz']; }
  return rangeOf(v,rf);
}
function rangeOf(v,fc){ if(v==='car5') return [fc-5000,fc+5000,'Center '+fHz(fc)+' · span 10 kHz']; if(v==='car25') return [fc-25000,fc+25000,'Center '+fHz(fc)+' · span 50 kHz']; if(v==='wide') return [0,1.2e6,'0 – 1.2 MHz']; return [0,10000,'0 – 10 kHz']; }
function drawSpec(){
  const cv=$('#spec'), {w,h,d}=fitCanvas(cv), ctx=cv.getContext('2d');
  grid(ctx,w,h,d,10,10);
  const s=sig(S.probes[S.spec.src]); const [f0,f1,lab]=specRange(s); const span=f1-f0, sigma=span/320;
  const dbY=db=>(10-db)/100*h;
  const comps=s.filter(c=>c.f>=f0-6*sigma&&c.f<=f1+6*sigma).map(c=>({f:c.f,db:20*Math.log10(c.f===0?c.a:c.a/Math.SQRT2)}));
  const path=new Path2D(), fill=new Path2D(); let seed=7;
  const N=Math.min(w,900); fill.moveTo(0,h);
  for(let i=0;i<=N;i++){ const f=f0+span*i/N; seed=(seed*16807)%2147483647; let p=Math.pow(10,(-88+((seed/2147483647)-.5)*6)/10);
    for(const c of comps){ const x=(f-c.f)/sigma; if(Math.abs(x)<8) p+=Math.pow(10,(c.db-4.34*x*x)/10); }
    const y=dbY(10*Math.log10(p)); const x=i*w/N; i?path.lineTo(x,y):path.moveTo(x,y); fill.lineTo(x,y); }
  fill.lineTo(w,h); fill.closePath();
  const gr=ctx.createLinearGradient(0,0,0,h); gr.addColorStop(0,'rgba(124,240,160,.28)'); gr.addColorStop(1,'rgba(124,240,160,0)'); ctx.fillStyle=gr; ctx.fill(fill);
  strokeGlow(ctx,path,'#7cf0a0',d);
  ctx.font=`${10*d}px JetBrains Mono, Consolas, monospace`; ctx.fillStyle='#6f8d7c';
  for(let j=1;j<10;j+=2) ctx.fillText((10-j*10)+'',4*d,j*h/10-3*d);
  if(S.spec.labels){
    const pk=comps.filter(c=>c.db>-70&&c.f>=f0&&c.f<=f1).sort((a,b)=>b.db-a.db).slice(0,5);
    ctx.font=`${10.5*d}px JetBrains Mono, Consolas, monospace`; ctx.textAlign='center';
    pk.forEach((c,i)=>{ const x=(c.f-f0)/span*w, y=dbY(c.db); ctx.fillStyle='#ffffff'; ctx.beginPath(); ctx.moveTo(x,y-4*d); ctx.lineTo(x-4*d,y-11*d); ctx.lineTo(x+4*d,y-11*d); ctx.fill();
      const t1=fHz(c.f), t2=c.db.toFixed(1)+' dBV'; const ly=Math.max(26*d,y-16*d-(i%2)*24*d); const lx=Math.max(40*d,Math.min(w-40*d,x));
      ctx.fillStyle='rgba(7,17,12,.82)'; const tw=Math.max(ctx.measureText(t1).width,ctx.measureText(t2).width); ctx.fillRect(lx-tw/2-3*d,ly-22*d,tw+6*d,24*d);
      ctx.fillStyle='#e9f5ee'; ctx.fillText(t1,lx,ly-11*d); ctx.fillStyle='#9fb0a6'; ctx.fillText(t2,lx,ly+1*d); });
    ctx.textAlign='left';
  }
  label(ctx,d,w,h,[[`CH${S.spec.src}`,S.spec.src===1?'#f1cc2a':'#2fd0e6'],[lab,'#c9d6cf'],[`RBW ${fHz(span/320*2.355)}`,'#8fa597']]);
}

/* ---------------- readouts ---------------- */
function updReadouts(){
  const card=(title,ch)=>{ const id=S.probes[ch]; const a=analyze(sig(id)); const [k,cls]=KIND[a.kind];
    return `<div class="card ro"><h3><span class="dot" style="background:${ch===1?'var(--ch1)':'var(--ch2)'}"></span>${title}<span class="pill ${cls}">${k}</span></h3>
      <div class="src">${id?sockName(id):'Not probed'}</div>
      <div class="big">${fV(a.vpp)}<small>pp</small></div>
      <dl><dt>${a.isRF?'Strongest line':'Frequency'}</dt><dd>${fHz(a.f)}</dd>
      ${a.isRF?`<dt>Envelope period</dt><dd>${a.fl&&a.fl<a.fc?(1e3/a.fl).toFixed(3)+' ms':'flat'}</dd>`:`<dt>Vrms (sine eq.)</dt><dd>${fV(a.vpp/2/Math.SQRT2)}</dd>`}
      ${a.thd!=null&&a.thd>0.05?`<dt>Harmonic content</dt><dd>${a.thd.toFixed(1)} %</dd>`:''}</dl></div>`; };
  const sa=analyze(sig(S.probes[S.spec.src])); let an, pw;
  if(sa.isRF){ const [k,cls]=KIND[sa.kind]; const mu=sa.mu!=null&&sa.lsb+sa.usb>1e-5?sa.mu:null;
    an=`<div class="card ro"><h3>Modulation · CH${S.spec.src}<span class="pill ${cls}">${k}</span></h3>
     <div class="big">${mu!=null&&(sa.kind==='am'||sa.kind==='over')?'μ '+mu.toFixed(3):k}</div>
     <div class="meter ${mu>1?'over':''}"><i style="width:${mu!=null?Math.min(100,mu/1.5*100):0}%"></i></div>
     <dl><dt>Carrier (${fHz(sa.fc)})</dt><dd>${fV(sa.car*2)} pp</dd><dt>Lower sideband</dt><dd>${fV(sa.lsb*2)} pp</dd><dt>Upper sideband</dt><dd>${fV(sa.usb*2)} pp</dd>
     <dt>Emax / Emin</dt><dd>${fV(sa.emax)} / ${fV(sa.emin)}</dd></dl></div>`;
    const pt=sa.pc+sa.psb, eta=pt>0?sa.psb/pt*100:0;
    pw=`<div class="card ro"><h3>Power · 50 Ω load</h3><div class="big">${fP(pt)}<small>total</small></div>
     <div class="meter"><i style="width:${eta}%"></i></div>
     <dl><dt>Carrier power Pc</dt><dd>${fP(sa.pc)}</dd><dt>Sideband power</dt><dd>${fP(sa.psb)}</dd><dt>Efficiency η</dt><dd>${eta.toFixed(1)} %</dd>
     <dt>Bandwidth</dt><dd>${sa.lsbF&&sa.usbF?fHz(sa.usbF-sa.lsbF):sa.kind==='usb'||sa.kind==='lsb'?'single sideband':'—'}</dd></dl></div>`;
  } else {
    an=`<div class="card ro"><h3>Modulation · CH${S.spec.src}<span class="pill">${KIND[sa.kind][0]}</span></h3><div class="big">${fHz(sa.f)}</div><dl><dt>Amplitude</dt><dd>${fV(sa.vpp)} pp</dd><dt>Lowest tone</dt><dd>${fHz(sa.fl)}</dd></dl><p class="note">Set the spectrum input to a probe on an RF socket to see carrier, sidebands and μ.</p></div>`;
    pw=`<div class="card ro"><h3>Power · 50 Ω load</h3><div class="big">${fP((sa.vpp/2/Math.SQRT2)**2/50)}<small>approx.</small></div><p class="note">Carrier and sideband power appear here for RF signals.</p></div>`;
  }
  $('#readouts').innerHTML=card('CH1',1)+card('CH2',2)+an+pw;
}

/* ---------------- manual ---------------- */
let TABLES=store.get('amtb.tables',{})||{}; const saveTables=()=>store.set('amtb.tables',TABLES);
let STEPS=store.get('amtb.steps',{})||{}; const saveSteps=()=>store.set('amtb.steps',STEPS);
let faultTries=0;
const isDone=id=>(TABLES[id]||[]).length>0;
function renderTabs(){ $('#expTabs').innerHTML=EXP.map((x,i)=>`<li><button data-i="${i}" aria-current="${i===S.exp}"><span class="n">${String(i+1).padStart(2,'0')}</span><span class="tt"><b>${x.short}</b><span>${x.wires.length} cords · ${x.steps.length} steps</span></span><span class="st ${isDone(x.id)?'done':''}" aria-label="${isDone(x.id)?'Completed':'Not completed'}"></span></button></li>`).join('');
  $('#expTabs').querySelectorAll('button').forEach(b=>b.onclick=()=>selectExp(+b.dataset.i,false));
  const n=EXP.filter(x=>isDone(x.id)).length; $('#stProg').textContent=`${n} / ${EXP.length}`; $('#progBar').style.width=(n/EXP.length*100)+'%'; $('#railProg').textContent=`${n} of ${EXP.length} done`; $('#railProg').className='pill'+(n?' ok':''); }
let PANE='overview';
function renderManual(){
  const x=EXP[S.exp]; const sd=STEPS[x.id]||[];
  $('#briefHead').innerHTML=`<div class="bh-text"><div class="eyebrow">Experiment ${String(S.exp+1).padStart(2,'0')} of ${String(EXP.length).padStart(2,'0')}</div><h2>${x.title}</h2><p class="aim">${x.aim}</p></div>
    <div class="bh-act"><button class="btn primary" id="mAuto">Auto-wire</button><button class="btn" id="mPre">Load preset</button>
    <button class="btn icon" id="mPrev" aria-label="Previous experiment" ${S.exp===0?'disabled':''}>‹</button><button class="btn icon" id="mNext" aria-label="Next experiment" ${S.exp===EXP.length-1?'disabled':''}>›</button></div>`;
  $('#mAuto').onclick=autoWire; $('#mPre').onclick=()=>{applyPreset(x); update(); hint('Preset settings loaded.');};
  $('#mPrev').onclick=()=>S.exp>0&&selectExp(S.exp-1,false); $('#mNext').onclick=()=>S.exp<EXP.length-1&&selectExp(S.exp+1,false);
  document.querySelectorAll('#paneTabs button').forEach(b=>{ b.setAttribute('aria-selected',b.dataset.t===PANE); b.onclick=()=>{PANE=b.dataset.t; renderManual(); updChecklist();}; });
  $('#cntSteps').textContent=`${sd.length}/${x.steps.length}`; $('#cntRows').textContent=(TABLES[x.id]||[]).length;
  const faultUI= x.id==='fault' ? `<div class="fault-box" style="margin-bottom:14px"><h3>Diagnosis</h3>
     <div class="btnrow"><button class="btn red" id="fIns">Insert hidden fault</button><button class="btn ghost" id="fRev">Reveal</button></div>
     <label for="fSel" style="font-size:.88rem">Faulty stage</label><select id="fSel">${FAULTS.map((f,i)=>`<option value="${i}">${f}</option>`).join('')}</select>
     <div class="btnrow"><button class="btn primary" id="fChk">Check</button></div><div id="fMsg" style="font-size:.88rem" aria-live="polite">${S.hidden!=null?'A hidden fault is active.':'No hidden fault yet.'}</div></div>` : '';
  let body='';
  if(PANE==='overview') body=`<div class="pane-grid">
      <div><h3>Theory</h3><p>${x.th[0]}</p><pre class="eq">${x.th[1]}</pre><p>${x.th[2]}</p></div>
      <div><div class="sec-head"><h3>Patch cords</h3><span class="pill" id="wireCount"></span></div>
        <ul class="checks" id="checks">${x.wires.map(([a,b])=>`<li><span class="tick"></span><span>${sockName(a)} → ${sockName(b)}</span></li>`).join('')}</ul>
        <div class="expect"><h3>What you should see</h3><p style="margin:0">${x.expect}</p></div></div></div>`;
  else if(PANE==='procedure') body=`${faultUI}<div class="sec-head"><h3>Procedure</h3><span class="pill" id="stepCount">${sd.length} of ${x.steps.length} done</span></div><p class="note" style="margin:0 0 8px">Click a step to tick it off.</p><ol class="steps" id="steps">${x.steps.map((s,i)=>`<li class="${sd.includes(i)?'done':''}"><button data-i="${i}">${s}</button></li>`).join('')}</ol>`;
  else if(PANE==='obs') body=`${x.id==='fault'?faultUI:''}<div class="obs-grid"><div><div class="tbl-wrap"><table class="obs" id="obs"></table></div>
      <div class="btnrow">${x.row?'<button class="btn primary" id="mRec">Record reading</button>':''}<button class="btn" id="mCopy">Copy as CSV</button><button class="btn ghost" id="mClr">Clear</button></div></div>
      <div id="chart">${x.plot?'':'<p class="note">This experiment has no plot.</p>'}</div></div>`;
  else body=x.viva.map(([q,a])=>`<details><summary>${q}</summary><p>${a}</p></details>`).join('');
  $('#expBody').innerHTML=body;
  const st=$('#steps'); if(st) st.querySelectorAll('button').forEach(b=>b.onclick=()=>{ const i=+b.dataset.i; const arr=STEPS[x.id]=STEPS[x.id]||[]; const k=arr.indexOf(i); k<0?arr.push(i):arr.splice(k,1); saveSteps(); b.parentElement.classList.toggle('done',k<0); $('#stepCount').textContent=`${arr.length} of ${x.steps.length} done`; $('#cntSteps').textContent=`${arr.length}/${x.steps.length}`; });
  if(x.row&&$('#mRec')) $('#mRec').onclick=()=>{ cache.clear(); (TABLES[x.id]=TABLES[x.id]||[]).push(x.row()); saveTables(); renderTable(); renderTabs(); hint('Reading recorded.'); };
  if($('#mCopy')) $('#mCopy').onclick=()=>copyText([x.cols,...(TABLES[x.id]||[])].map(r=>r.map(v=>`"${String(v).replace(/"/g,'""')}"`).join(',')).join('\n'),'Table copied as CSV.');
  if($('#mClr')) $('#mClr').onclick=()=>{ TABLES[x.id]=[]; saveTables(); renderTable(); renderTabs(); };
  if(x.id==='fault'&&$('#fIns')){
    $('#fIns').onclick=()=>{ const pool=[0,2,4,5,6,7]; S.hidden=pool[Math.floor(Math.random()*pool.length)]; faultTries=0; $('#fMsg').textContent='A hidden fault is active. Start probing.'; update(); };
    $('#fRev').onclick=()=>{ $('#fMsg').textContent= S.hidden!=null? 'The fault was: '+FAULTS[S.hidden]+'.' : 'No hidden fault is active.'; };
    $('#fChk').onclick=()=>{ if(S.hidden==null){ $('#fMsg').textContent='Insert a hidden fault first.'; return; }
      const g=+$('#fSel').value, ok=g===S.hidden; faultTries++;
      (TABLES.fault=TABLES.fault||[]).push([String(faultTries),FAULTS[g],ok?'Correct':'Not this one']); saveTables(); renderTable(); renderTabs();
      if(ok){ $('#fMsg').innerHTML='<b style="color:var(--ok)">Correct.</b> Fault cleared.'; S.hidden=null; update(); } else $('#fMsg').innerHTML='<b style="color:var(--bad)">Not this stage.</b> Keep probing.'; };
  }
  renderTable();
}
function copyText(txt,ok){ try{ navigator.clipboard.writeText(txt).then(()=>hint(ok),()=>hint('Copy was blocked. Select the table and copy it manually.')); }catch(e){ hint('Copy was blocked. Select the table and copy it manually.'); } }
function tableHTML(x,rows){ return `<thead><tr><th>#</th>${x.cols.map(c=>`<th>${c}</th>`).join('')}</tr></thead><tbody>${rows.length?rows.map((r,i)=>`<tr><td>${i+1}</td>${r.map(v=>`<td>${v}</td>`).join('')}</tr>`).join(''):`<tr><td class="empty" colspan="${x.cols.length+1}">${x.row?'No readings yet. Set the controls and press Record reading.':'Diagnosis attempts appear here.'}</td></tr>`}</tbody>`; }
function renderTable(){ const x=EXP[S.exp], rows=TABLES[x.id]||[]; $('#cntRows').textContent=rows.length; if(!$('#obs')) return; $('#obs').innerHTML=tableHTML(x,rows); if(x.plot) $('#chart').innerHTML=chartSVG(x,rows); }
function parseVal(s){ const m=String(s).replace('>','').trim().match(/^([+-]?[\d.]+)\s*(MHz|kHz|Hz|mV|V|°|dB|%)?/); if(!m) return NaN; const v=parseFloat(m[1]), u=m[2]; return u==='MHz'?v*1e6:u==='kHz'?v*1e3:u==='mV'?v/1e3:v; }
function niceTicks(a,b,n){ if(a===b){a-=1;b+=1;} const st=Math.pow(10,Math.floor(Math.log10((b-a)/n))); const m=[1,2,5,10].find(k=>(b-a)/(k*st)<=n)*st; const out=[]; for(let v=Math.ceil(a/m)*m;v<=b+1e-12;v+=m) out.push(+v.toPrecision(6)); return out; }
function chartSVG(x,rows){
  const [xi,yi]=x.plot; const pts=rows.map(r=>[parseVal(r[xi]),parseVal(r[yi])]).filter(p=>isFinite(p[0])&&isFinite(p[1])).sort((a,b)=>a[0]-b[0]);
  if(pts.length<2) return `<div class="chart"><p class="note" style="margin:4px">Record two or more readings to plot <b>${x.cols[yi]}</b> against <b>${x.cols[xi]}</b>.</p></div>`;
  const W=360,H=200,L=46,R=12,Tp=14,B=34;
  let x0=Math.min(...pts.map(p=>p[0])), x1=Math.max(...pts.map(p=>p[0])), y0=Math.min(0,...pts.map(p=>p[1])), y1=Math.max(...pts.map(p=>p[1]));
  const xt=niceTicks(x0,x1,5), yt=niceTicks(y0,y1,4); x0=Math.min(x0,xt[0]); x1=Math.max(x1,xt[xt.length-1]); y0=Math.min(y0,yt[0]); y1=Math.max(y1,yt[yt.length-1]); if(x1===x0)x1=x0+1; if(y1===y0)y1=y0+1;
  const X=v=>L+(v-x0)/(x1-x0)*(W-L-R), Y=v=>H-B-(v-y0)/(y1-y0)*(H-Tp-B);
  const fmt=v=>Math.abs(v)>=1000?(v/1000)+'k':String(+v.toPrecision(3));
  let g=`<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${x.cols[yi]} versus ${x.cols[xi]}">`;
  for(const t of yt) g+=`<line x1="${L}" x2="${W-R}" y1="${Y(t)}" y2="${Y(t)}" stroke="#d8e0d9"/><text x="${L-6}" y="${Y(t)+4}" text-anchor="end" font-size="10" fill="#5b6a61" font-family="JetBrains Mono, monospace">${fmt(t)}</text>`;
  for(const t of xt) g+=`<text x="${X(t)}" y="${H-B+14}" text-anchor="middle" font-size="10" fill="#5b6a61" font-family="JetBrains Mono, monospace">${fmt(t)}</text>`;
  g+=`<line x1="${L}" x2="${W-R}" y1="${H-B}" y2="${H-B}" stroke="#9aa79f"/>`;
  g+=`<path d="${pts.map((p,i)=>(i?'L':'M')+X(p[0]).toFixed(1)+','+Y(p[1]).toFixed(1)).join(' ')}" fill="none" stroke="#0b6b3f" stroke-width="2"/>`;
  for(const p of pts) g+=`<circle cx="${X(p[0])}" cy="${Y(p[1])}" r="3.5" fill="#cf262d" stroke="#fff" stroke-width="1.5"/>`;
  g+=`<text x="${(L+W-R)/2}" y="${H-4}" text-anchor="middle" font-size="11" fill="#2b3a31" font-family="Source Sans 3, sans-serif">${x.cols[xi]}</text>`;
  g+=`<text x="12" y="${(Tp+H-B)/2}" text-anchor="middle" font-size="11" fill="#2b3a31" transform="rotate(-90 12 ${(Tp+H-B)/2})" font-family="Source Sans 3, sans-serif">${x.cols[yi]}</text></svg>`;
  return `<div class="chart">${g}</div>`;
}
function updChecklist(){ const x=EXP[S.exp]; const lis=document.querySelectorAll('#checks li'); let n=0;
  x.wires.forEach(([a,b],i)=>{ const ok=S.wires.some(w=>w.from===a&&w.to===b); if(ok) n++; lis[i]&&lis[i].classList.toggle('done',ok); });
  const p=$('#wireCount'); if(p){ p.textContent=`${n} of ${x.wires.length} cords`; p.className='pill '+(n===x.wires.length?'ok':n?'warn':''); } }
function applyPreset(x){ Object.assign(S.ctl,x.pre.ctl); Object.assign(S.scope,x.pre.scope); S.probes={...x.pre.probes}; Object.assign(S.spec,x.pre.spec); }
function autoWire(){ const x=EXP[S.exp]; for(const [a,b] of x.wires) addWire(a,b); S.pending=null; cache.clear(); autoset(); hint('All cords for this experiment are patched.'); update(); }
function selectExp(i,wire){ S.exp=i; S.hidden=null; S.pending=null; S.wires=[]; S.cordN=0; applyPreset(EXP[i]); if(wire) for(const [a,b] of EXP[i].wires) addWire(a,b);
  renderTabs(); renderManual(); if(!wire) hint('Board cleared. Patch the cords listed in the manual, or press Auto-wire.'); update(); }
function renderReport(){
  const parts=EXP.map((x,i)=>{ const rows=TABLES[x.id]||[]; return `<h3>${i+1}. ${x.title}</h3><div class="tbl-wrap"><table class="obs">${tableHTML(x,rows)}</table></div>${x.plot&&rows.length>1?chartSVG(x,rows):''}`; }).join('');
  $('#repBody').innerHTML=`<p class="note" style="margin-top:0">Readings recorded in this browser. ${EXP.filter(x=>isDone(x.id)).length} of ${EXP.length} experiments have data.</p>`+parts;
}

/* ---------------- controls panel ---------------- */
const GROUPS=[['afg','AF signal generator'],['rfg','RF signal generator'],['pre','Audio pre-amplifier'],['bm1','Balanced modulator 1'],['bm2','Balanced modulator 2'],['bm3','Balanced modulator 3'],['ssb','SSB block'],['dem','Balanced demodulator'],['apa','Audio power amp']];
function buildControls(){
  let h='';
  for(const [g,t] of GROUPS){ h+=`<div class="ctl-group"><h3>${t}</h3>`;
    if(g==='afg') h+=`<div class="ctl-row"><label for="c-afWave">Waveform</label><select id="c-afWave"><option value="sine">Sine</option><option value="square">Square</option><option value="tri">Triangle</option></select></div>`;
    if(g==='rfg') h+=`<div class="ctl-row"><label for="c-rfSel">Frequency (DIP)</label><select id="c-rfSel">${RF_OPTS.map((f,i)=>`<option value="${i}">${fHz(f)}</option>`).join('')}</select></div>`;
    if(g==='pre') h+=`<div class="ctl-row"><label for="c-mic">Microphone</label><input type="checkbox" id="c-mic"></div>`;
    if(g==='ssb') h+=`<div class="ctl-row"><label for="c-ssbMode">Summer</label><select id="c-ssbMode"><option value="1">A + B</option><option value="-1">A − B</option></select></div>`;
    for(const k in KN) if(KN[k].g===g) h+=`<div class="ctl-row"><label for="c-${k}">${KN[k].l}</label><output id="o-${k}"></output><input type="range" id="c-${k}" min="0" max="1000" step="1"></div>`;
    h+='</div>'; }
  h+=`<div class="ctl-group"><h3>Fault switches (instructor)</h3><div class="faults">${FAULTS.map((f,i)=>`<label><input type="checkbox" id="c-f${i}"> ${i+1}. ${f}</label>`).join('')}</div></div>`;
  $('#controls').innerHTML=h;
  for(const k in KN) $('#c-'+k).addEventListener('input',e=>{ S.ctl[k]=denorm(k,e.target.value/1000); update(); });
  $('#c-afWave').onchange=e=>{S.ctl.afWave=e.target.value; update();};
  $('#c-rfSel').onchange=e=>{S.ctl.rfSel=+e.target.value; update();};
  $('#c-mic').onchange=e=>{S.ctl.mic=e.target.checked; update();};
  $('#c-ssbMode').onchange=e=>{S.ctl.ssbMode=+e.target.value; update();};
  FAULTS.forEach((_,i)=>$('#c-f'+i).onchange=e=>{ S.faults[i]=e.target.checked; update(); });
}
function syncControls(){
  for(const k in KN){ const el=$('#c-'+k); if(document.activeElement!==el) el.value=Math.round(norm(k,S.ctl[k])*1000); $('#o-'+k).textContent=fmtK(k,S.ctl[k]); }
  $('#c-afWave').value=S.ctl.afWave; $('#c-rfSel').value=S.ctl.rfSel; $('#c-mic').checked=S.ctl.mic; $('#c-ssbMode').value=S.ctl.ssbMode;
  FAULTS.forEach((_,i)=>{ const el=$('#c-f'+i); el.checked=S.faults[i]; el.disabled=S.hidden!=null; });
  const sc=S.scope; $('#tb').value=sc.tb; $('#v1').value=sc.v1; $('#v2').value=sc.v2; $('#pos1').value=sc.pos1; $('#pos2').value=sc.pos2; $('#xy').checked=sc.xy; $('#ch2on').checked=sc.ch2; $('#curs').checked=sc.cur; $('#trig').value=sc.trig;
  const rb=$('#run'); rb.setAttribute('aria-pressed',sc.run); rb.textContent=sc.run?'Run':'Stopped'; $('#runLed').className='led'+(sc.run?'':' off');
  $('#scope').classList.toggle('cur',sc.cur&&!sc.xy);
  $('#spsrc').value=S.spec.src; $('#spview').value=S.spec.view; $('#maxhold').checked=S.spec.labels;
  const spk=$('#spk'); spk.setAttribute('aria-pressed',AUD.on); spk.textContent=AUD.on?'Speaker on':'Speaker off';
  ['patch','p1','p2'].forEach(m=>$('#m-'+m).setAttribute('aria-pressed',S.mode===m));
}
function autoset(){
  const sc=S.scope; let fl=Infinity;
  for(const ch of [1,2]){ const a=analyze(sig(S.probes[ch])); if(a.vpp>1e-4){ const vd=VDS.find(v=>a.vpp/v<=3.4)||5; sc['v'+ch]=vd; } if(a.fl>0) fl=Math.min(fl,a.fl); }
  if(isFinite(fl)) sc.tb=TBS.find(t=>10*t>=2/fl)||TBS[TBS.length-1];
}

/* ---------------- audio ---------------- */
const AUD={ctx:null,on:false,src:null,g:null,key:'',tm:0};
function toggleAudio(){
  if(!AUD.on){ try{ AUD.ctx=AUD.ctx||new (window.AudioContext||window.webkitAudioContext)(); AUD.ctx.resume(); AUD.on=true; AUD.key=''; hint('Speaker on. You hear the AUDIO PA output.'); }catch(e){ hint('Audio is not available in this browser.'); } }
  else { AUD.on=false; stopSrc(); hint('Speaker off.'); }
  update();
}
function stopSrc(){ if(AUD.src){ const {src,g}=AUD; const t=AUD.ctx.currentTime; g.gain.setTargetAtTime(0,t,0.02); src.stop(t+0.15); AUD.src=null; } AUD.key=''; }
function audioRefresh(){
  if(!AUD.on) return;
  const s=sig('apa.out').filter(c=>c.f>=20&&c.f<16000&&c.a>1e-4);
  const key=s.map(c=>Math.round(c.f)+':'+c.a.toFixed(4)+':'+c.p.toFixed(2)).join('|');
  if(key===AUD.key) return; AUD.key=key; clearTimeout(AUD.tm); AUD.tm=setTimeout(()=>buildAudio(s),120);
}
function buildAudio(s){
  const ctx=AUD.ctx, sr=ctx.sampleRate, N=Math.round(sr), buf=ctx.createBuffer(1,N,sr), dch=buf.getChannelData(0);
  const w=s.map(c=>TAU*Math.round(c.f)/sr), a=s.map(c=>c.a), p=s.map(c=>c.p);
  for(let i=0;i<N;i++){ let v=0; for(let k=0;k<w.length;k++) v+=a[k]*Math.cos(w[k]*i+p[k]); dch[i]=Math.tanh(v*0.35)*0.9; }
  const old=AUD.src?{src:AUD.src,g:AUD.g}:null;
  const src=ctx.createBufferSource(); src.buffer=buf; src.loop=true; const g=ctx.createGain(); const t=ctx.currentTime;
  g.gain.setValueAtTime(0,t); g.gain.linearRampToValueAtTime(1,t+0.05); src.connect(g); g.connect(ctx.destination); src.start();
  if(old){ old.g.gain.setTargetAtTime(0,t,0.02); old.src.stop(t+0.15); }
  AUD.src=src; AUD.g=g;
}

/* ---------------- wiring up ---------------- */
let raf=0;
function update(){ cache.clear(); if(!raf) raf=requestAnimationFrame(render); }
function render(){ raf=0; updBoard(); drawScope(false); drawSpec(); updReadouts(); updChecklist(); syncControls(); audioRefresh(); }
const reduce=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
let lastLive=0;
function loop(ts){ requestAnimationFrame(loop); if(document.hidden||reduce) return; if(ts-lastLive<PERF.iv) return; lastLive=ts;
  if(S.scope.run){ if(S.scope.trig==='free') S.t0+=S.scope.tb*0.37; const t=performance.now(); drawScope(true); tunePerf(performance.now()-t); } }
function initInstruments(){
  $('#tb').innerHTML=TBS.map(t=>`<option value="${t}">${fTB(t)}</option>`).join('');
  for(const id of ['v1','v2']) $('#'+id).innerHTML=VDS.map(v=>`<option value="${v}">${fVd(v)}</option>`).join('');
  $('#tb').onchange=e=>{S.scope.tb=+e.target.value; update();};
  $('#v1').onchange=e=>{S.scope.v1=+e.target.value; update();};
  $('#v2').onchange=e=>{S.scope.v2=+e.target.value; update();};
  $('#pos1').oninput=e=>{S.scope.pos1=+e.target.value; update();};
  $('#pos2').oninput=e=>{S.scope.pos2=+e.target.value; update();};
  $('#xy').onchange=e=>{S.scope.xy=e.target.checked; update();};
  $('#ch2on').onchange=e=>{S.scope.ch2=e.target.checked; update();};
  $('#curs').onchange=e=>{S.scope.cur=e.target.checked; update();};
  $('#trig').onchange=e=>{S.scope.trig=e.target.value; S.t0=0; update();};
  $('#run').onclick=()=>{S.scope.run=!S.scope.run; update();};
  $('#autoset').onclick=()=>{ cache.clear(); autoset(); update(); };
  $('#spsrc').onchange=e=>{S.spec.src=+e.target.value; update();};
  $('#spview').onchange=e=>{S.spec.view=e.target.value; update();};
  $('#maxhold').onchange=e=>{S.spec.labels=e.target.checked; update();};
  $('#spk').onclick=toggleAudio;
  for(const m of ['patch','p1','p2']) $('#m-'+m).onclick=()=>setMode(m);
  $('#tb-autowire').onclick=autoWire;
  $('#tb-clear').onclick=()=>{ S.wires=[]; S.pending=null; hint('All cords removed.'); update(); };
  $('#board').addEventListener('click',()=>{ if(S.pending){ S.pending=null; hint('Cord cancelled.'); update(); } });
  // scope cursors
  const cv=$('#scope'); let dragC=null;
  cv.addEventListener('pointerdown',e=>{ if(!S.scope.cur||S.scope.xy) return; const r=cv.getBoundingClientRect(); const f=(e.clientX-r.left)/r.width;
    dragC=Math.abs(f-S.scope.c1)<Math.abs(f-S.scope.c2)?'c1':'c2'; S.scope[dragC]=Math.min(1,Math.max(0,f)); cv.setPointerCapture(e.pointerId); update(); });
  cv.addEventListener('pointermove',e=>{ if(!dragC) return; const r=cv.getBoundingClientRect(); S.scope[dragC]=Math.min(1,Math.max(0,(e.clientX-r.left)/r.width)); update(); });
  cv.addEventListener('pointerup',()=>dragC=null); cv.addEventListener('pointercancel',()=>dragC=null);
  // report dialog
  const dlg=$('#report');
  $('#openReport').onclick=()=>{ renderReport(); try{ dlg.showModal(); }catch(e){ dlg.setAttribute('open',''); } };
  $('#repClose').onclick=()=>dlg.close();
  $('#repCopy').onclick=()=>copyText(EXP.map((x,i)=>`${i+1}. ${x.title}\n`+[x.cols,...(TABLES[x.id]||[])].map(r=>r.join('\t')).join('\n')).join('\n\n'),'Report copied.');
  $('#resetAll').onclick=()=>{ TABLES={}; STEPS={}; saveTables(); saveSteps(); renderTabs(); renderManual(); hint('All recorded readings cleared.'); };
  // shortcuts
  document.addEventListener('keydown',e=>{
    if(e.key==='Escape'&&S.pending){ S.pending=null; hint('Cord cancelled.'); update(); return; }
    const tg=e.target; if(e.ctrlKey||e.metaKey||e.altKey||/INPUT|SELECT|TEXTAREA/.test(tg.tagName)||dlg.open) return;
    const k=e.key.toLowerCase();
    if(k==='p') setMode('patch'); else if(k==='1') setMode('p1'); else if(k==='2') setMode('p2');
    else if(k==='w') autoWire(); else if(k==='a'){ cache.clear(); autoset(); update(); }
    else if(k==='r'){ S.scope.run=!S.scope.run; update(); } else if(k==='c'){ S.scope.cur=!S.scope.cur; update(); } else if(k==='s') toggleAudio();
  });
  if('ResizeObserver' in window){ const ro=new ResizeObserver(()=>update()); ro.observe($('#scope')); ro.observe($('#spec')); } else window.addEventListener('resize',update);
}
function setMode(m){ S.mode=m; S.pending=null; defaultHint(); update(); }
// Performance profile: slower devices (Raspberry Pi, low-end phones) draw fewer trace columns at a lower frame rate.
const PERF={iv:50,cols:1000,sn:18,avg:0};
if(/armv7l|aarch64|Raspbian/i.test(navigator.userAgent)||((navigator.hardwareConcurrency||8)<=4&&(navigator.deviceMemory||8)<=2)) Object.assign(PERF,{iv:100,cols:600,sn:10});
function tunePerf(ms){ PERF.avg=PERF.avg*0.85+ms*0.15; if(PERF.avg>28&&PERF.cols>360){ PERF.cols=Math.round(PERF.cols*0.75); PERF.sn=Math.max(8,PERF.sn-3); PERF.iv=Math.min(160,PERF.iv+20); PERF.avg=0; } }
// Board zoom: "Fit" scales the board to the card; fixed levels keep sockets large enough to tap on small screens.
const ZOOMS=[0.5,0.6,0.75,0.9,1,1.25,1.5]; let ZOOM=null;
function fitRatio(){ return ($(".board-scroll").clientWidth||1200)/1200; }
function applyZoom(){ const svg=$("#board"); svg.style.maxWidth=ZOOM==null?"":"none"; if(ZOOM==null){ svg.style.width="100%"; $("#zLbl").textContent="Fit"; } else { svg.style.width=Math.round(1200*ZOOM)+"px"; $("#zLbl").textContent=Math.round(ZOOM*100)+"%"; } }
function initZoom(){
  ZOOM= $(".board-scroll").clientWidth<820 ? 0.75 : null;
  $("#zIn").onclick=()=>{ const cur=ZOOM==null?fitRatio():ZOOM; const n=ZOOMS.find(z=>z>cur+0.001); if(n) ZOOM=n; applyZoom(); };
  $("#zOut").onclick=()=>{ const cur=ZOOM==null?fitRatio():ZOOM; const n=[...ZOOMS].reverse().find(z=>z<cur-0.001); ZOOM=(n&&n>fitRatio()+0.001)?n:null; applyZoom(); };
  $("#zFit").onclick=()=>{ ZOOM=null; applyZoom(); };
  applyZoom();
}
buildBoard(); buildControls(); initInstruments(); initZoom();
selectExp(0,true); defaultHint();
requestAnimationFrame(loop);
})();
